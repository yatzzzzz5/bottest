import { logger } from '../../utils/logger';
import * as ccxt from 'ccxt';

export interface PriceData {
  exchange: string;
  symbol: string;
  bid: number;
  ask: number;
  timestamp: number;
  volume: number;
  confidence: number;
}

export interface ValidationResult {
  isValid: boolean;
  confidence: number;
  priceDeviation: number;
  volumeAnomaly: boolean;
  timestampSkew: number;
  warnings: string[];
  recommendedAction: 'ACCEPT' | 'REJECT' | 'MANUAL_REVIEW';
}

export interface CrossValidationResult {
  symbol: string;
  consensusPrice: number;
  priceRange: { min: number; max: number };
  volumeWeightedAverage: number;
  outlierExchanges: string[];
  validationScore: number;
  recommendations: string[];
}

export class MarketDataValidator {
  private exchanges: Map<string, ccxt.Exchange> = new Map();
  private priceHistory: Map<string, PriceData[]> = new Map();
  private validationRules: Map<string, any> = new Map();
  private maxPriceDeviation: number = 0.05; // 5% max deviation
  private maxTimestampSkew: number = 5000; // 5 seconds
  private minVolumeThreshold: number = 10000; // $10k minimum volume

  async initialize(): Promise<void> {
    logger.info('🔍 Initializing Market Data Validator...');
    
    // Initialize validation rules
    this.initializeValidationRules();
    
    // Initialize exchange connections
    await this.initializeExchanges();
    
    logger.info('✅ Market Data Validator initialized');
  }

  private initializeValidationRules(): void {
    this.validationRules.set('price_deviation', {
      maxDeviation: 0.05, // 5%
      minSamples: 3,
      weightThreshold: 0.7
    });
    
    this.validationRules.set('volume_anomaly', {
      minVolume: 10000,
      maxVolumeMultiplier: 10,
      volumeSpikeThreshold: 5
    });
    
    this.validationRules.set('timestamp_validation', {
      maxSkew: 5000, // 5 seconds
      minUpdateFrequency: 1000 // 1 second
    });
    
    this.validationRules.set('cross_exchange', {
      minExchanges: 2,
      consensusThreshold: 0.8,
      outlierThreshold: 0.15
    });
  }

  private async initializeExchanges(): Promise<void> {
    const exchangeConfigs = [
      { name: 'binance', id: 'binance' },
      { name: 'okx', id: 'okx' },
      { name: 'coinbase', id: 'coinbase' },
      { name: 'kraken', id: 'kraken' }
    ];

    for (const config of exchangeConfigs) {
      try {
        // Check if exchange constructor exists
        if (!ccxt[config.id] || typeof ccxt[config.id] !== 'function') {
          logger.warn(`⚠️ Exchange constructor not found for ${config.id}, skipping`);
          continue;
        }

        const exchange = new (ccxt as any)[config.id]({
          enableRateLimit: true,
          timeout: 10000,
          options: {
            defaultType: 'spot'
          }
        });
        
        await exchange.loadMarkets();
        this.exchanges.set(config.name, exchange);
        logger.info(`✅ ${config.name} exchange initialized`);
      } catch (error) {
        logger.warn(`⚠️ Failed to initialize ${config.name}:`, error.message);
      }
    }
  }

  // Validate single price data point
  async validatePriceData(priceData: PriceData): Promise<ValidationResult> {
    try {
      const warnings: string[] = [];
      let confidence = 1.0;
      let priceDeviation = 0;
      let volumeAnomaly = false;
      let timestampSkew = 0;

      // 1. Price deviation check
      const historicalPrices = this.getHistoricalPrices(priceData.symbol);
      if (historicalPrices.length > 0) {
        const avgPrice = historicalPrices.reduce((sum, p) => sum + (p.bid + p.ask) / 2, 0) / historicalPrices.length;
        const currentPrice = (priceData.bid + priceData.ask) / 2;
        priceDeviation = Math.abs(currentPrice - avgPrice) / avgPrice;
        
        if (priceDeviation > this.maxPriceDeviation) {
          warnings.push(`Price deviation ${(priceDeviation * 100).toFixed(2)}% exceeds threshold`);
          confidence -= 0.3;
        }
      }

      // 2. Volume anomaly check
      if (priceData.volume < this.minVolumeThreshold) {
        warnings.push(`Volume ${priceData.volume} below minimum threshold`);
        volumeAnomaly = true;
        confidence -= 0.2;
      }

      // 3. Timestamp validation
      const now = Date.now();
      timestampSkew = Math.abs(now - priceData.timestamp);
      if (timestampSkew > this.maxTimestampSkew) {
        warnings.push(`Timestamp skew ${timestampSkew}ms exceeds threshold`);
        confidence -= 0.2;
      }

      // 4. Bid-ask spread validation
      const spread = (priceData.ask - priceData.bid) / priceData.bid;
      if (spread > 0.01) { // 1% spread
        warnings.push(`Wide bid-ask spread ${(spread * 100).toFixed(2)}%`);
        confidence -= 0.1;
      }

      // 5. Exchange-specific validation
      const exchangeValidation = await this.validateExchangeSpecific(priceData);
      if (!exchangeValidation.isValid) {
        warnings.push(...exchangeValidation.warnings);
        confidence -= 0.2;
      }

      // Determine recommended action
      let recommendedAction: 'ACCEPT' | 'REJECT' | 'MANUAL_REVIEW' = 'ACCEPT';
      if (confidence < 0.5) {
        recommendedAction = 'REJECT';
      } else if (confidence < 0.8 || warnings.length > 2) {
        recommendedAction = 'MANUAL_REVIEW';
      }

      // Store validated data
      this.storePriceData(priceData);

      return {
        isValid: confidence >= 0.5,
        confidence,
        priceDeviation,
        volumeAnomaly,
        timestampSkew,
        warnings,
        recommendedAction
      };

    } catch (error) {
      logger.error('❌ Price validation failed:', error);
      return {
        isValid: false,
        confidence: 0,
        priceDeviation: 0,
        volumeAnomaly: true,
        timestampSkew: 0,
        warnings: ['Validation error occurred'],
        recommendedAction: 'REJECT'
      };
    }
  }

  // Cross-validate prices across multiple exchanges
  async crossValidatePrices(symbol: string): Promise<CrossValidationResult> {
    try {
      logger.info(`🔍 Cross-validating prices for ${symbol}...`);

      const priceData: PriceData[] = [];
      const outlierExchanges: string[] = [];
      const recommendations: string[] = [];

      // Collect prices from all exchanges
      for (const [exchangeName, exchange] of this.exchanges) {
        try {
          const ticker = await exchange.fetchTicker(symbol);
          const price: PriceData = {
            exchange: exchangeName,
            symbol,
            bid: ticker.bid || 0,
            ask: ticker.ask || 0,
            timestamp: ticker.timestamp || Date.now(),
            volume: ticker.baseVolume || 0,
            confidence: 1.0
          };

          // Validate individual price
          const validation = await this.validatePriceData(price);
          if (validation.isValid) {
            priceData.push(price);
          } else {
            outlierExchanges.push(exchangeName);
            recommendations.push(`${exchangeName}: ${validation.warnings.join(', ')}`);
          }
        } catch (error) {
          logger.warn(`⚠️ Failed to fetch ${symbol} from ${exchangeName}:`, error);
          outlierExchanges.push(exchangeName);
        }
      }

      if (priceData.length < 2) {
        return {
          symbol,
          consensusPrice: 0,
          priceRange: { min: 0, max: 0 },
          volumeWeightedAverage: 0,
          outlierExchanges,
          validationScore: 0,
          recommendations: ['Insufficient valid price data']
        };
      }

      // Calculate consensus price
      const prices = priceData.map(p => (p.bid + p.ask) / 2);
      const consensusPrice = prices.reduce((sum, price) => sum + price, 0) / prices.length;
      
      // Calculate price range
      const priceRange = {
        min: Math.min(...prices),
        max: Math.max(...prices)
      };

      // Calculate volume-weighted average
      const totalVolume = priceData.reduce((sum, p) => sum + p.volume, 0);
      const volumeWeightedAverage = priceData.reduce((sum, p) => {
        const weight = p.volume / totalVolume;
        return sum + ((p.bid + p.ask) / 2) * weight;
      }, 0);

      // Calculate validation score
      const priceDeviation = (priceRange.max - priceRange.min) / consensusPrice;
      const validationScore = Math.max(0, 1 - priceDeviation * 2);

      // Generate recommendations
      if (priceDeviation > 0.02) {
        recommendations.push('High price deviation detected - manual review recommended');
      }
      if (outlierExchanges.length > 0) {
        recommendations.push(`Exclude outliers: ${outlierExchanges.join(', ')}`);
      }
      if (validationScore < 0.8) {
        recommendations.push('Low validation score - consider manual intervention');
      }

      logger.info(`✅ Cross-validation completed for ${symbol}: Score ${validationScore.toFixed(3)}`);

      return {
        symbol,
        consensusPrice,
        priceRange,
        volumeWeightedAverage,
        outlierExchanges,
        validationScore,
        recommendations
      };

    } catch (error) {
      logger.error(`❌ Cross-validation failed for ${symbol}:`, error);
      return {
        symbol,
        consensusPrice: 0,
        priceRange: { min: 0, max: 0 },
        volumeWeightedAverage: 0,
        outlierExchanges: [],
        validationScore: 0,
        recommendations: ['Cross-validation error occurred']
      };
    }
  }

  // Validate exchange-specific data
  private async validateExchangeSpecific(priceData: PriceData): Promise<{ isValid: boolean; warnings: string[] }> {
    const warnings: string[] = [];
    
    try {
      const exchange = this.exchanges.get(priceData.exchange);
      if (!exchange) {
        warnings.push('Exchange not available');
        return { isValid: false, warnings };
      }

      // Check if market is active
      const market = exchange.markets[priceData.symbol];
      if (!market || !market.active) {
        warnings.push('Market not active');
        return { isValid: false, warnings };
      }

      // Check minimum order size
      if (market.limits?.amount?.min && priceData.volume < market.limits.amount.min) {
        warnings.push('Volume below minimum order size');
      }

      // Check price precision
      if (market.precision?.price) {
        const pricePrecision = Math.pow(10, -market.precision.price);
        if (priceData.bid % pricePrecision !== 0 || priceData.ask % pricePrecision !== 0) {
          warnings.push('Price precision mismatch');
        }
      }

      return { isValid: warnings.length === 0, warnings };

    } catch (error) {
      warnings.push('Exchange validation error');
      return { isValid: false, warnings };
    }
  }

  // Get historical prices for comparison
  private getHistoricalPrices(symbol: string): PriceData[] {
    const key = `${symbol}_history`;
    return this.priceHistory.get(key) || [];
  }

  // Store validated price data
  private storePriceData(priceData: PriceData): void {
    const key = `${priceData.symbol}_history`;
    const history = this.priceHistory.get(key) || [];
    
    // Keep only last 100 data points
    history.push(priceData);
    if (history.length > 100) {
      history.shift();
    }
    
    this.priceHistory.set(key, history);
  }

  // Get validation statistics
  getValidationStats(): {
    totalValidations: number;
    successRate: number;
    averageConfidence: number;
    activeExchanges: number;
    monitoredSymbols: number;
  } {
    let totalValidations = 0;
    let successfulValidations = 0;
    let totalConfidence = 0;

    for (const history of this.priceHistory.values()) {
      totalValidations += history.length;
      successfulValidations += history.filter(p => p.confidence > 0.5).length;
      totalConfidence += history.reduce((sum, p) => sum + p.confidence, 0);
    }

    return {
      totalValidations,
      successRate: totalValidations > 0 ? successfulValidations / totalValidations : 0,
      averageConfidence: totalValidations > 0 ? totalConfidence / totalValidations : 0,
      activeExchanges: this.exchanges.size,
      monitoredSymbols: this.priceHistory.size
    };
  }

  // Emergency price validation (for critical trades)
  async emergencyValidation(symbol: string, price: number, exchange: string): Promise<boolean> {
    try {
      logger.warn(`🚨 Emergency validation for ${symbol} at ${price} on ${exchange}`);
      
      const crossValidation = await this.crossValidatePrices(symbol);
      
      // Emergency criteria: price must be within 2% of consensus
      const priceDeviation = Math.abs(price - crossValidation.consensusPrice) / crossValidation.consensusPrice;
      
      if (priceDeviation > 0.02) {
        logger.error(`❌ Emergency validation FAILED: Price deviation ${(priceDeviation * 100).toFixed(2)}%`);
        return false;
      }
      
      if (crossValidation.validationScore < 0.7) {
        logger.error(`❌ Emergency validation FAILED: Validation score ${crossValidation.validationScore.toFixed(3)}`);
        return false;
      }
      
      logger.info(`✅ Emergency validation PASSED for ${symbol}`);
      return true;
      
    } catch (error) {
      logger.error('❌ Emergency validation error:', error);
      return false;
    }
  }
}
