import { logger } from '../../utils/logger';
import ccxt from 'ccxt';

export interface MarketMakingConfig {
  symbols: string[];
  targetSpreadBps: number; // desired quoted spread per side
  maxInventoryUsd: number; // cap net inventory exposure
  ladderLevels: number;
  ladderStepBps: number;
  timeboxMs: number;
}

export class MarketMakingModule {
  public name = 'market_making';
  private config: MarketMakingConfig;
  private ex: any;
  private invUsd: number = 0;
  private spreadEwmaBps: number = 5;

  constructor(config: MarketMakingConfig) {
    this.config = config;
    this.ex = new ccxt.binance({ enableRateLimit: true, options: { defaultType: 'spot' } });
  }

  async initialize(): Promise<void> {
    try { await this.ex.loadMarkets(); } catch {}
    logger.info('✅ Market-making module ready');
  }

  async runTick(): Promise<void> {
    for (const symbol of this.config.symbols) {
      try {
        const ob = await this.ex.fetchOrderBook(symbol, 5);
        const bid = ob.bids?.[0]?.[0];
        const ask = ob.asks?.[0]?.[0];
        if (!bid || !ask) continue;
        const mid = (bid + ask) / 2;
        const rawSpreadBps = ((ask - bid) / mid) * 10000;
        // EWMA of observed spread; target is max(config target, observed*1.1)
        this.spreadEwmaBps = this.spreadEwmaBps * 0.9 + rawSpreadBps * 0.1;
        const targetBps = Math.max(this.config.targetSpreadBps, Math.min(50, this.spreadEwmaBps * 1.1));
        const step = (this.config.ladderStepBps / 10000) * mid;
        const spread = (targetBps / 10000) * mid;
        const pxBid = mid - spread / 2;
        const pxAsk = mid + spread / 2;
        const sizeUsdPerLevel = Math.max(10, this.config.maxInventoryUsd * 0.05);
        const amtBid = (sizeUsdPerLevel / pxBid);
        const amtAsk = (sizeUsdPerLevel / pxAsk);
        // Place small ladders post-only around mid; cancel shortly after
        const orders: any[] = [];
        for (let i = 0; i < this.config.ladderLevels; i++) {
          const pb = pxBid - i * step; const pa = pxAsk + i * step;
          try { orders.push(await this.ex.createOrder(symbol, 'limit', 'buy', amtBid, pb, { postOnly: true })); } catch {}
          try { orders.push(await this.ex.createOrder(symbol, 'limit', 'sell', amtAsk, pa, { postOnly: true })); } catch {}
        }
        await new Promise(r => setTimeout(r, this.config.timeboxMs));
        // Best-effort cancel leftovers
        for (const o of orders) { try { await this.ex.cancelOrder(o.id, symbol); } catch {} }
      } catch (e) {
        // ignore tick errors
      }
    }
  }
}


