import { logger } from '../../utils/logger';
import ccxt from 'ccxt';

export interface TriArbConfig { symbols: string[]; minEdgeBps: number; maxChain: number; }

export class TriangularArbModule {
  public name = 'triangular_arb';
  private config: TriArbConfig;
  private ex: any;
  constructor(config: TriArbConfig) { this.config = config; this.ex = new ccxt.binance({ enableRateLimit: true }); }
  async initialize(): Promise<void> { try { await this.ex.loadMarkets(); } catch {} }
  async runTick(): Promise<void> {
    // Lightweight: check a few synthetic triangles (A/USDT, A/BTC, BTC/USDT)
    const quote = 'USDT';
    const top = this.config.symbols.filter(s => s.endsWith('/USDT')).map(s => s.split('/')[0]);
    const uniq = Array.from(new Set(top));
    const candidates = uniq.slice(0, Math.min(this.config.maxChain, uniq.length));
    for (const base of candidates) {
      try {
        const a_usdt = await this.safePrice(`${base}/USDT`);
        const a_btc = await this.safePrice(`${base}/BTC`);
        const btc_usdt = await this.safePrice('BTC/USDT');
        if (!a_usdt || !a_btc || !btc_usdt) continue;
        const synth = a_btc * btc_usdt; // A/USDT via BTC
        const edge = (a_usdt - synth) / a_usdt; // positive if direct cheaper than route
        if (Math.abs(edge) * 10000 >= this.config.minEdgeBps) {
          logger.debug(`TriArb edge ${base}: ${(edge*10000).toFixed(2)} bps`);
          // Execution omitted for safety; would require atomic engine
        }
      } catch {}
    }
  }
  private async safePrice(sym: string): Promise<number | null> { try { const t = await this.ex.fetchTicker(sym); return t?.last ?? null; } catch { return null; } }
}


