import { logger } from '../../utils/logger';
import { TradingSignal, MarketAnalysis } from '../ai-engine';
import { Order } from '../exchanges/exchange-connector';

export interface StrategyRequest {
  symbol: string;
  signal: TradingSignal;
  positionSize: number;
  analysis: MarketAnalysis;
  timestamp: Date;
}

export interface StrategyResult {
  success: boolean;
  orderId?: string;
  error?: string;
  order?: Order;
  executionTime?: number;
}

export interface Strategy {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  parameters: Record<string, any>;
}

export class StrategyExecutor {
  private isRunning: boolean = false;
  private strategies: Map<string, Strategy> = new Map();
  private executionHistory: StrategyResult[] = [];

  constructor() {
    this.initializeDefaultStrategies();
  }

  private initializeDefaultStrategies(): void {
    const defaultStrategies: Strategy[] = [
      {
        id: 'momentum',
        name: 'Momentum Strategy',
        description: 'Trades based on price momentum and technical indicators',
        isActive: true,
        parameters: {
          rsiThreshold: 30,
          macdThreshold: 0.5,
          volumeThreshold: 1000000
        }
      },
      {
        id: 'mean-reversion',
        name: 'Mean Reversion Strategy',
        description: 'Trades based on price returning to mean levels',
        isActive: true,
        parameters: {
          bollingerDeviation: 2,
          smaPeriod: 20,
          entryThreshold: 0.1
        }
      },
      {
        id: 'breakout',
        name: 'Breakout Strategy',
        description: 'Trades based on price breakouts from key levels',
        isActive: true,
        parameters: {
          breakoutThreshold: 0.05,
          volumeConfirmation: true,
          retestEnabled: true
        }
      }
    ];

    defaultStrategies.forEach(strategy => {
      this.strategies.set(strategy.id, strategy);
    });
  }

  async initialize(): Promise<void> {
    logger.info('🎯 Initializing Strategy Executor...');
    logger.info('✅ Strategy Executor initialized');
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('⚠️ Strategy Executor is already running');
      return;
    }

    logger.info('🚀 Starting Strategy Executor...');
    this.isRunning = true;
    logger.info('✅ Strategy Executor started');
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      logger.warn('⚠️ Strategy Executor is not running');
      return;
    }

    logger.info('🛑 Stopping Strategy Executor...');
    this.isRunning = false;
    logger.info('✅ Strategy Executor stopped');
  }

  async execute(request: StrategyRequest): Promise<StrategyResult> {
    const startTime = Date.now();
    
    try {
      logger.info(`🎯 Executing strategy for ${request.symbol}: ${request.signal.type} ${request.signal.strength}`);

      // Validate request
      if (!this.validateRequest(request)) {
        return {
          success: false,
          error: 'Invalid strategy request',
          executionTime: Date.now() - startTime
        };
      }

      // Select appropriate strategy based on signal and analysis
      const strategy = this.selectStrategy(request);
      if (!strategy) {
        return {
          success: false,
          error: 'No suitable strategy found',
          executionTime: Date.now() - startTime
        };
      }

      // Execute the strategy
      const result = await this.executeStrategy(strategy, request);
      
      // Record execution
      this.executionHistory.push({
        ...result,
        executionTime: Date.now() - startTime
      });

      logger.info(`✅ Strategy execution completed: ${result.success ? 'SUCCESS' : 'FAILED'}`);
      return result;

    } catch (error) {
      const result: StrategyResult = {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        executionTime: Date.now() - startTime
      };

      this.executionHistory.push(result);
      logger.error('❌ Strategy execution failed:', error);
      return result;
    }
  }

  private validateRequest(request: StrategyRequest): boolean {
    if (!request.symbol || !request.signal || !request.analysis) {
      return false;
    }

    if (request.positionSize <= 0) {
      return false;
    }

    if (request.signal.confidence < 0 || request.signal.confidence > 1) {
      return false;
    }

    return true;
  }

  private selectStrategy(request: StrategyRequest): Strategy | null {
    // Simple strategy selection based on signal type and analysis
    const { signal, analysis } = request;

    if (signal.type === 'BUY') {
      if (analysis.technical.rsi < 30) {
        return this.strategies.get('mean-reversion') || null;
      } else if (analysis.technical.confidence > 0.7) {
        return this.strategies.get('momentum') || null;
      }
    } else if (signal.type === 'SELL') {
      if (analysis.technical.rsi > 70) {
        return this.strategies.get('mean-reversion') || null;
      } else if (analysis.riskScore > 0.8) {
        return this.strategies.get('breakout') || null;
      }
    }

    // Default to momentum strategy
    return this.strategies.get('momentum') || null;
  }

  private async executeStrategy(strategy: Strategy, request: StrategyRequest): Promise<StrategyResult> {
    try {
      logger.info(`🎯 Executing ${strategy.name} for ${request.symbol}`);

      // Mock order creation
      const order: Order = {
        id: `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        symbol: request.symbol,
        side: request.signal.type === 'BUY' ? 'BUY' : 'SELL',
        type: 'MARKET',
        amount: request.positionSize,
        status: 'FILLED',
        timestamp: new Date()
      };

      // Simulate execution delay
      await new Promise(resolve => setTimeout(resolve, 100));

      logger.info(`✅ Strategy ${strategy.name} executed successfully: ${order.id}`);

      return {
        success: true,
        orderId: order.id,
        order
      };

    } catch (error) {
      logger.error(`❌ Strategy ${strategy.name} execution failed:`, error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Strategy execution failed'
      };
    }
  }

  async getStrategies(): Promise<Strategy[]> {
    return Array.from(this.strategies.values());
  }

  async getStrategy(id: string): Promise<Strategy | null> {
    return this.strategies.get(id) || null;
  }

  async updateStrategy(id: string, updates: Partial<Strategy>): Promise<boolean> {
    try {
      const strategy = this.strategies.get(id);
      if (!strategy) {
        return false;
      }

      const updatedStrategy = { ...strategy, ...updates };
      this.strategies.set(id, updatedStrategy);

      logger.info(`📊 Strategy ${id} updated`);
      return true;

    } catch (error) {
      logger.error(`❌ Failed to update strategy ${id}:`, error);
      return false;
    }
  }

  async addStrategy(strategy: Strategy): Promise<boolean> {
    try {
      if (this.strategies.has(strategy.id)) {
        logger.warn(`⚠️ Strategy ${strategy.id} already exists`);
        return false;
      }

      this.strategies.set(strategy.id, strategy);
      logger.info(`📊 Strategy ${strategy.id} added`);
      return true;

    } catch (error) {
      logger.error(`❌ Failed to add strategy ${strategy.id}:`, error);
      return false;
    }
  }

  async removeStrategy(id: string): Promise<boolean> {
    try {
      const removed = this.strategies.delete(id);
      if (removed) {
        logger.info(`📊 Strategy ${id} removed`);
      }
      return removed;

    } catch (error) {
      logger.error(`❌ Failed to remove strategy ${id}:`, error);
      return false;
    }
  }

  async getExecutionHistory(limit: number = 100): Promise<StrategyResult[]> {
    return this.executionHistory.slice(-limit);
  }

  async getExecutionStats(): Promise<{
    total: number;
    successful: number;
    failed: number;
    averageExecutionTime: number;
  }> {
    const total = this.executionHistory.length;
    const successful = this.executionHistory.filter(r => r.success).length;
    const failed = total - successful;
    const averageExecutionTime = this.executionHistory.reduce((sum, r) => sum + (r.executionTime || 0), 0) / total;

    return {
      total,
      successful,
      failed,
      averageExecutionTime
    };
  }
}
