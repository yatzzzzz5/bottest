import { logger } from '../../utils/logger';

export interface Position {
  id: string;
  symbol: string;
  side: 'LONG' | 'SHORT';
  size: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPnL: number;
  realizedPnL: number;
  stopLoss?: number;
  takeProfit?: number;
  trailingStop?: number;
  timestamp: Date;
  lastUpdate: Date;
}

export interface PositionUpdate {
  symbol: string;
  price: number;
  timestamp: Date;
}

export class PositionManager {
  private isRunning: boolean = false;
  private positions: Map<string, Position> = new Map();
  private positionHistory: Position[] = [];

  async initialize(): Promise<void> {
    logger.info('📊 Initializing Position Manager...');
    logger.info('✅ Position Manager initialized');
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('⚠️ Position Manager is already running');
      return;
    }

    logger.info('🚀 Starting Position Manager...');
    this.isRunning = true;
    logger.info('✅ Position Manager started');
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      logger.warn('⚠️ Position Manager is not running');
      return;
    }

    logger.info('🛑 Stopping Position Manager...');
    this.isRunning = false;
    logger.info('✅ Position Manager stopped');
  }

  async openPosition(
    symbol: string,
    side: 'LONG' | 'SHORT',
    size: number,
    entryPrice: number,
    stopLoss?: number,
    takeProfit?: number
  ): Promise<Position> {
    try {
      const position: Position = {
        id: `pos_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        symbol,
        side,
        size,
        entryPrice,
        currentPrice: entryPrice,
        unrealizedPnL: 0,
        realizedPnL: 0,
        stopLoss,
        takeProfit,
        timestamp: new Date(),
        lastUpdate: new Date()
      };

      this.positions.set(symbol, position);
      logger.info(`📊 Opened position: ${side} ${size} ${symbol} @ ${entryPrice}`);

      return position;

    } catch (error) {
      logger.error('❌ Failed to open position:', error);
      throw error;
    }
  }

  async closePosition(symbol: string, exitPrice: number): Promise<Position | null> {
    try {
      const position = this.positions.get(symbol);
      if (!position) {
        logger.warn(`⚠️ No position found for ${symbol}`);
        return null;
      }

      // Calculate PnL
      const pnl = position.side === 'LONG' 
        ? (exitPrice - position.entryPrice) * position.size
        : (position.entryPrice - exitPrice) * position.size;

      position.realizedPnL = pnl;
      position.currentPrice = exitPrice;
      position.lastUpdate = new Date();

      // Move to history
      this.positions.delete(symbol);
      this.positionHistory.push(position);

      logger.info(`📊 Closed position: ${symbol} @ ${exitPrice}, PnL: ${pnl.toFixed(2)}`);

      return position;

    } catch (error) {
      logger.error(`❌ Failed to close position ${symbol}:`, error);
      return null;
    }
  }

  async updatePosition(update: PositionUpdate): Promise<void> {
    try {
      const position = this.positions.get(update.symbol);
      if (!position) return;

      position.currentPrice = update.price;
      position.lastUpdate = update.timestamp;

      // Calculate unrealized PnL
      position.unrealizedPnL = position.side === 'LONG'
        ? (update.price - position.entryPrice) * position.size
        : (position.entryPrice - update.price) * position.size;

    } catch (error) {
      logger.error(`❌ Failed to update position ${update.symbol}:`, error);
    }
  }

  async getPosition(symbol: string): Promise<Position | null> {
    return this.positions.get(symbol) || null;
  }

  async getActivePositions(): Promise<Position[]> {
    return Array.from(this.positions.values());
  }

  async getPositionHistory(symbol?: string, limit: number = 100): Promise<Position[]> {
    let history = this.positionHistory.slice(-limit);
    
    if (symbol) {
      history = history.filter(position => position.symbol === symbol);
    }
    
    return history;
  }

  async updateStopLoss(symbol: string, stopLoss: number): Promise<boolean> {
    try {
      const position = this.positions.get(symbol);
      if (!position) {
        logger.warn(`⚠️ No position found for ${symbol}`);
        return false;
      }

      position.stopLoss = stopLoss;
      logger.info(`📊 Updated stop-loss for ${symbol}: ${stopLoss}`);
      return true;

    } catch (error) {
      logger.error(`❌ Failed to update stop-loss for ${symbol}:`, error);
      return false;
    }
  }

  async updateTakeProfit(symbol: string, takeProfit: number): Promise<boolean> {
    try {
      const position = this.positions.get(symbol);
      if (!position) {
        logger.warn(`⚠️ No position found for ${symbol}`);
        return false;
      }

      position.takeProfit = takeProfit;
      logger.info(`📊 Updated take-profit for ${symbol}: ${takeProfit}`);
      return true;

    } catch (error) {
      logger.error(`❌ Failed to update take-profit for ${symbol}:`, error);
      return false;
    }
  }

  async updateTrailingStop(symbol: string, trailingStop: number): Promise<boolean> {
    try {
      const position = this.positions.get(symbol);
      if (!position) {
        logger.warn(`⚠️ No position found for ${symbol}`);
        return false;
      }

      position.trailingStop = trailingStop;
      logger.info(`📊 Updated trailing stop for ${symbol}: ${trailingStop}`);
      return true;

    } catch (error) {
      logger.error(`❌ Failed to update trailing stop for ${symbol}:`, error);
      return false;
    }
  }

  async getTotalPnL(): Promise<{
    unrealized: number;
    realized: number;
    total: number;
  }> {
    const activePositions = Array.from(this.positions.values());
    const closedPositions = this.positionHistory;

    const unrealized = activePositions.reduce((sum, pos) => sum + pos.unrealizedPnL, 0);
    const realized = closedPositions.reduce((sum, pos) => sum + pos.realizedPnL, 0);

    return {
      unrealized,
      realized,
      total: unrealized + realized
    };
  }

  async getPositionStats(): Promise<{
    total: number;
    long: number;
    short: number;
    profitable: number;
    losing: number;
  }> {
    const activePositions = Array.from(this.positions.values());
    const closedPositions = this.positionHistory;
    const allPositions = [...activePositions, ...closedPositions];

    return {
      total: allPositions.length,
      long: allPositions.filter(p => p.side === 'LONG').length,
      short: allPositions.filter(p => p.side === 'SHORT').length,
      profitable: allPositions.filter(p => p.realizedPnL > 0 || p.unrealizedPnL > 0).length,
      losing: allPositions.filter(p => p.realizedPnL < 0 || p.unrealizedPnL < 0).length
    };
  }
}
