import { logger } from '../../utils/logger';

/**
 * COMPOUND PROFIT MANAGER
 * 
 * Günlük 2x için: Her kazanç otomatik olarak sermayeye eklenir
 * Böylece compound interest etkisi ile daha hızlı büyür
 */

export interface CompoundStrategy {
  type: 'IMMEDIATE' | 'HOURLY' | 'DAILY' | 'THRESHOLD';
  threshold?: number; // USD threshold before reinvesting
  minCompound?: number; // Minimum amount to compound
}

export interface CompoundRecord {
  id: string;
  timestamp: Date;
  beforeBalance: number;
  profit: number;
  afterBalance: number;
  compoundPercent: number;
}

export class CompoundProfitManager {
  private strategy: CompoundStrategy;
  private compoundHistory: CompoundRecord[] = [];
  private pendingProfit: number = 0;
  private lastCompoundTime: number = 0;
  private currentBalance: number;
  
  constructor(initialBalance: number, strategy: CompoundStrategy = { type: 'IMMEDIATE' }) {
    this.currentBalance = initialBalance;
    this.strategy = strategy;
    this.lastCompoundTime = Date.now();
  }

  /**
   * Profit kaydet ve compound et
   */
  recordProfit(profit: number): number {
    if (profit <= 0) return this.currentBalance;
    
    this.pendingProfit += profit;
    
    // Compound strategy'ye göre karar ver
    switch (this.strategy.type) {
      case 'IMMEDIATE':
        return this.compoundImmediate();
      
      case 'THRESHOLD':
        if (this.pendingProfit >= (this.strategy.threshold || 1)) {
          return this.compoundImmediate();
        }
        return this.currentBalance;
      
      case 'HOURLY':
        const now = Date.now();
        if (now - this.lastCompoundTime >= 60 * 60 * 1000) {
          return this.compoundImmediate();
        }
        return this.currentBalance;
      
      case 'DAILY':
        const today = new Date();
        const lastCompound = new Date(this.lastCompoundTime);
        if (today.getDate() !== lastCompound.getDate()) {
          return this.compoundImmediate();
        }
        return this.currentBalance;
      
      default:
        return this.currentBalance;
    }
  }

  private compoundImmediate(): number {
    if (this.pendingProfit < (this.strategy.minCompound || 0.01)) {
      return this.currentBalance;
    }
    
    const beforeBalance = this.currentBalance;
    this.currentBalance += this.pendingProfit;
    const afterBalance = this.currentBalance;
    const compoundPercent = (this.pendingProfit / beforeBalance) * 100;
    
    const record: CompoundRecord = {
      id: `comp_${Date.now()}`,
      timestamp: new Date(),
      beforeBalance,
      profit: this.pendingProfit,
      afterBalance,
      compoundPercent
    };
    
    this.compoundHistory.push(record);
    this.lastCompoundTime = Date.now();
    
    logger.info(`💰 Profit compounded: $${this.pendingProfit.toFixed(2)} | Balance: $${beforeBalance.toFixed(2)} -> $${afterBalance.toFixed(2)} (+${compoundPercent.toFixed(2)}%)`);
    
    const profit = this.pendingProfit;
    this.pendingProfit = 0;
    
    return afterBalance;
  }

  getBalance(): number {
    return this.currentBalance + this.pendingProfit;
  }

  getCompoundedBalance(): number {
    return this.currentBalance;
  }

  getPendingProfit(): number {
    return this.pendingProfit;
  }

  getCompoundHistory(): CompoundRecord[] {
    return this.compoundHistory;
  }

  /**
   * Compound statistics
   */
  getStats(): {
    totalCompounded: number;
    compoundCount: number;
    avgCompoundPercent: number;
    currentBalance: number;
    growthFactor: number;
  } {
    const totalCompounded = this.compoundHistory.reduce((sum, r) => sum + r.profit, 0);
    const avgCompoundPercent = this.compoundHistory.length > 0
      ? this.compoundHistory.reduce((sum, r) => sum + r.compoundPercent, 0) / this.compoundHistory.length
      : 0;
    
    // Growth factor: how many times initial balance has grown
    const initialBalance = this.compoundHistory[0]?.beforeBalance || this.currentBalance;
    const growthFactor = this.currentBalance / initialBalance;
    
    return {
      totalCompounded,
      compoundCount: this.compoundHistory.length,
      avgCompoundPercent,
      currentBalance: this.currentBalance,
      growthFactor
    };
  }
}

