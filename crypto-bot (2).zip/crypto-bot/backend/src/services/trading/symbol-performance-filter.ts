import { logger } from '../../utils/logger';

/**
 * SYMBOL PERFORMANCE FILTER
 * 
 * Her coin için performansı takip eder ve
 * kötü performans gösteren coinleri devre dışı bırakır
 * Günlük 2x için en karlı coinlere odaklanır
 */

export interface SymbolPerformance {
  symbol: string;
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  totalProfit: number;
  avgProfit: number;
  avgLoss: number;
  profitFactor: number;
  sharpeRatio: number;
  maxDrawdown: number;
  lastTradeTime: number;
  isEnabled: boolean;
  score: number; // 0-100 performance score
}

export interface FilterConfig {
  minWinRate: number; // % (default: 50%)
  minProfitFactor: number; // (default: 1.5)
  maxConsecutiveLosses: number; // (default: 5)
  minTrades: number; // Minimum trades before filtering (default: 20)
  enableAutoDisable: boolean; // Auto-disable bad performers
}

export class SymbolPerformanceFilter {
  private performances: Map<string, SymbolPerformance> = new Map();
  private config: FilterConfig;
  private disabledSymbols: Set<string> = new Set();
  
  constructor(config?: Partial<FilterConfig>) {
    this.config = {
      minWinRate: 50, // %50 minimum win rate
      minProfitFactor: 1.5, // 1.5x minimum profit factor
      maxConsecutiveLosses: 5,
      minTrades: 20,
      enableAutoDisable: true,
      ...config
    };
  }

  /**
   * Trade kaydı ekle
   */
  recordTrade(symbol: string, profit: number, isWin: boolean): void {
    if (!this.performances.has(symbol)) {
      this.performances.set(symbol, {
        symbol,
        trades: 0,
        wins: 0,
        losses: 0,
        winRate: 0,
        totalProfit: 0,
        avgProfit: 0,
        avgLoss: 0,
        profitFactor: 0,
        sharpeRatio: 0,
        maxDrawdown: 0,
        lastTradeTime: Date.now(),
        isEnabled: true,
        score: 50
      });
    }
    
    const perf = this.performances.get(symbol)!;
    perf.trades++;
    perf.lastTradeTime = Date.now();
    
    if (isWin) {
      perf.wins++;
      perf.totalProfit += profit;
      perf.avgProfit = (perf.avgProfit * (perf.wins - 1) + profit) / perf.wins;
    } else {
      perf.losses++;
      perf.totalProfit += profit; // Negative
      perf.avgLoss = (perf.avgLoss * (perf.losses - 1) + Math.abs(profit)) / perf.losses;
    }
    
    // Update metrics
    perf.winRate = (perf.wins / perf.trades) * 100;
    perf.profitFactor = perf.avgLoss > 0 ? perf.avgProfit / perf.avgLoss : 0;
    perf.score = this.calculateScore(perf);
    
    // Auto-disable if bad performance
    if (this.config.enableAutoDisable && this.shouldDisable(perf)) {
      this.disableSymbol(symbol);
    }
    
    // Re-enable if performance improved
    if (!perf.isEnabled && this.shouldEnable(perf)) {
      this.enableSymbol(symbol);
    }
  }

  /**
   * Symbol'ün aktif olup olmadığını kontrol et
   */
  isSymbolEnabled(symbol: string): boolean {
    const perf = this.performances.get(symbol);
    if (!perf) return true; // Yeni symbol, aktif
    
    return perf.isEnabled && !this.disabledSymbols.has(symbol);
  }

  /**
   * En iyi performans gösteren symbol'leri getir
   */
  getTopPerformers(count: number = 5): SymbolPerformance[] {
    return Array.from(this.performances.values())
      .filter(p => p.isEnabled && p.trades >= this.config.minTrades)
      .sort((a, b) => b.score - a.score)
      .slice(0, count);
  }

  /**
   * Kötü performans gösteren symbol'leri getir
   */
  getUnderperformers(): SymbolPerformance[] {
    return Array.from(this.performances.values())
      .filter(p => 
        p.trades >= this.config.minTrades &&
        (p.winRate < this.config.minWinRate || p.profitFactor < this.config.minProfitFactor)
      );
  }

  private calculateScore(perf: SymbolPerformance): number {
    let score = 50; // Base score
    
    // Win rate contribution (40% weight)
    score += (perf.winRate - 50) * 0.4;
    
    // Profit factor contribution (30% weight)
    if (perf.profitFactor > 0) {
      score += Math.min((perf.profitFactor - 1) * 30, 30);
    }
    
    // Total profit contribution (20% weight)
    score += Math.min(perf.totalProfit / 10, 20);
    
    // Trade count contribution (10% weight)
    score += Math.min((perf.trades / 100) * 10, 10);
    
    return Math.max(0, Math.min(100, score));
  }

  private shouldDisable(perf: SymbolPerformance): boolean {
    if (perf.trades < this.config.minTrades) return false;
    
    return (
      perf.winRate < this.config.minWinRate ||
      perf.profitFactor < this.config.minProfitFactor ||
      perf.totalProfit < -100 // $100'dan fazla kayıp
    );
  }

  private shouldEnable(perf: SymbolPerformance): boolean {
    return (
      perf.trades >= this.config.minTrades &&
      perf.winRate >= this.config.minWinRate &&
      perf.profitFactor >= this.config.minProfitFactor
    );
  }

  private disableSymbol(symbol: string): void {
    const perf = this.performances.get(symbol);
    if (perf && perf.isEnabled) {
      perf.isEnabled = false;
      this.disabledSymbols.add(symbol);
      logger.warn(`⚠️ Symbol disabled due to poor performance: ${symbol} (Win Rate: ${perf.winRate.toFixed(1)}%, Profit Factor: ${perf.profitFactor.toFixed(2)})`);
    }
  }

  private enableSymbol(symbol: string): void {
    const perf = this.performances.get(symbol);
    if (perf && !perf.isEnabled) {
      perf.isEnabled = true;
      this.disabledSymbols.delete(symbol);
      logger.info(`✅ Symbol re-enabled due to improved performance: ${symbol}`);
    }
  }

  getPerformance(symbol: string): SymbolPerformance | undefined {
    return this.performances.get(symbol);
  }

  getAllPerformances(): SymbolPerformance[] {
    return Array.from(this.performances.values());
  }
}

