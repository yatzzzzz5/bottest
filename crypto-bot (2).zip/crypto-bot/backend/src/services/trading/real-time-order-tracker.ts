import { logger } from '../../utils/logger';
import { EventEmitter } from 'events';
import { Server } from 'socket.io';

export interface TrackedOrder {
  id: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  type: 'MARKET' | 'LIMIT' | 'STOP' | 'STOP_LIMIT';
  amount: number;
  price?: number;
  status: 'PENDING' | 'OPEN' | 'PARTIALLY_FILLED' | 'FILLED' | 'CANCELLED' | 'REJECTED' | 'EXPIRED';
  filledAmount: number;
  avgFillPrice: number;
  timestamp: number;
  updatedAt: number;
  exchange?: string;
  fee?: number;
  pnl?: number;
  relatedTradeId?: string;
  strategy?: string;
}

export class RealTimeOrderTracker extends EventEmitter {
  private orders: Map<string, TrackedOrder> = new Map();
  private io: Server | null = null;
  private updateInterval: NodeJS.Timeout | null = null;
  private isRunning: boolean = false;

  constructor() {
    super();
  }

  initialize(io: Server): void {
    this.io = io;
    this.isRunning = true;
    this.startPeriodicUpdates();
    logger.info('✅ Real-time Order Tracker initialized');
  }

  // Add or update order
  trackOrder(order: TrackedOrder): void {
    const existing = this.orders.get(order.id);
    const isNew = !existing;
    
    this.orders.set(order.id, {
      ...order,
      updatedAt: Date.now()
    });

    // Emit real-time update via Socket.IO
    if (this.io) {
      if (isNew) {
        this.io.emit('order:new', order);
      } else {
        this.io.emit('order:update', order);
      }
    }

    // Emit event for internal listeners
    if (isNew) {
      this.emit('order:added', order);
    } else {
      this.emit('order:updated', order);
    }

    logger.debug(`📊 Order tracked: ${order.id} (${order.status})`);
  }

  // Update order status
  updateOrderStatus(orderId: string, status: TrackedOrder['status'], updates?: Partial<TrackedOrder>): boolean {
    const order = this.orders.get(orderId);
    if (!order) {
      logger.warn(`⚠️ Order not found: ${orderId}`);
      return false;
    }

    const updatedOrder: TrackedOrder = {
      ...order,
      ...updates,
      status,
      updatedAt: Date.now()
    };

    this.trackOrder(updatedOrder);
    return true;
  }

  // Get order by ID
  getOrder(orderId: string): TrackedOrder | undefined {
    return this.orders.get(orderId);
  }

  // Get all active orders
  getActiveOrders(): TrackedOrder[] {
    return Array.from(this.orders.values()).filter(
      order => order.status === 'PENDING' || order.status === 'OPEN' || order.status === 'PARTIALLY_FILLED'
    );
  }

  // Get all orders (with optional filters)
  getAllOrders(filters?: {
    symbol?: string;
    side?: 'BUY' | 'SELL';
    status?: TrackedOrder['status'];
    strategy?: string;
    limit?: number;
  }): TrackedOrder[] {
    let orders = Array.from(this.orders.values());

    if (filters) {
      if (filters.symbol) {
        orders = orders.filter(o => o.symbol === filters.symbol);
      }
      if (filters.side) {
        orders = orders.filter(o => o.side === filters.side);
      }
      if (filters.status) {
        orders = orders.filter(o => o.status === filters.status);
      }
      if (filters.strategy) {
        orders = orders.filter(o => o.strategy === filters.strategy);
      }
    }

    // Sort by timestamp (newest first)
    orders.sort((a, b) => b.timestamp - a.timestamp);

    // Apply limit
    if (filters?.limit) {
      orders = orders.slice(0, filters.limit);
    }

    return orders;
  }

  // Get order statistics
  getOrderStats(): {
    total: number;
    active: number;
    filled: number;
    cancelled: number;
    byStatus: Record<string, number>;
    bySymbol: Record<string, number>;
    totalVolume: number;
    avgFillTime: number;
  } {
    const orders = Array.from(this.orders.values());
    const byStatus: Record<string, number> = {};
    const bySymbol: Record<string, number> = {};

    let totalVolume = 0;
    let totalFillTime = 0;
    let filledCount = 0;

    orders.forEach(order => {
      // Count by status
      byStatus[order.status] = (byStatus[order.status] || 0) + 1;

      // Count by symbol
      bySymbol[order.symbol] = (bySymbol[order.symbol] || 0) + 1;

      // Calculate volume
      if (order.status === 'FILLED') {
        totalVolume += order.filledAmount * (order.avgFillPrice || order.price || 0);
        if (order.updatedAt && order.timestamp) {
          totalFillTime += order.updatedAt - order.timestamp;
          filledCount++;
        }
      }
    });

    return {
      total: orders.length,
      active: orders.filter(o => o.status === 'OPEN' || o.status === 'PENDING' || o.status === 'PARTIALLY_FILLED').length,
      filled: byStatus['FILLED'] || 0,
      cancelled: byStatus['CANCELLED'] || 0,
      byStatus,
      bySymbol,
      totalVolume,
      avgFillTime: filledCount > 0 ? totalFillTime / filledCount : 0
    };
  }

  // Start periodic updates
  private startPeriodicUpdates(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }

    // Emit order stats every 5 seconds
    this.updateInterval = setInterval(() => {
      if (this.io && this.isRunning) {
        const stats = this.getOrderStats();
        const activeOrders = this.getActiveOrders();

        this.io.emit('orders:stats', {
          stats,
          activeOrders,
          timestamp: Date.now()
        });
      }
    }, 5000);
  }

  // Cleanup old orders (keep last 1000)
  cleanupOldOrders(): void {
    const orders = Array.from(this.orders.values());
    if (orders.length > 1000) {
      // Sort by timestamp and keep newest 1000
      orders.sort((a, b) => b.timestamp - a.timestamp);
      const toKeep = orders.slice(0, 1000);

      // Clear and re-add
      this.orders.clear();
      toKeep.forEach(order => {
        this.orders.set(order.id, order);
      });

      logger.info(`🧹 Cleaned up old orders, kept ${toKeep.length} most recent`);
    }
  }

  // Stop tracker
  stop(): void {
    this.isRunning = false;
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    logger.info('🛑 Real-time Order Tracker stopped');
  }
}

// Singleton instance
export const orderTracker = new RealTimeOrderTracker();

