import { logger } from '../../utils/logger';
import { TradingSignal, MarketAnalysis } from '../ai-engine';

export interface RiskConfig {
  maxPositionSize: number; // Maximum position size as % of portfolio
  maxDailyLoss: number; // Maximum daily loss as % of portfolio
  maxDrawdown: number; // Maximum drawdown as % of portfolio
  stopLossPercentage: number; // Default stop-loss percentage
  takeProfitPercentage: number; // Default take-profit percentage
  maxOpenPositions: number; // Maximum number of open positions
  correlationLimit: number; // Maximum correlation between positions
}

export interface RiskCheck {
  approved: boolean;
  reason?: string;
  riskScore: number;
}

export interface StopLossCheck {
  triggered: boolean;
  reason?: string;
  price?: number;
}

export interface TakeProfitCheck {
  triggered: boolean;
  reason?: string;
  price?: number;
}

export interface RiskMetrics {
  currentDrawdown: number;
  dailyPnL: number;
  openPositions: number;
  portfolioValue: number;
  riskScore: number;
  volatility: number;
}

export class RiskManager {
  private isRunning: boolean = false;
  private config: RiskConfig;
  private dailyPnL: number = 0;
  private portfolioValue: number = 10000; // Starting value
  private maxPortfolioValue: number = 10000;

  constructor() {
    this.config = {
      maxPositionSize: 0.05, // 5% max position size
      maxDailyLoss: 0.02, // 2% max daily loss
      maxDrawdown: 0.15, // 15% max drawdown
      stopLossPercentage: 0.05, // 5% default stop-loss
      takeProfitPercentage: 0.10, // 10% default take-profit
      maxOpenPositions: 10,
      correlationLimit: 0.7
    };
  }

  async initialize(): Promise<void> {
    logger.info('🛡️ Initializing Risk Manager...');
    logger.info('✅ Risk Manager initialized');
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('⚠️ Risk Manager is already running');
      return;
    }

    logger.info('🚀 Starting Risk Manager...');
    this.isRunning = true;
    logger.info('✅ Risk Manager started');
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      logger.warn('⚠️ Risk Manager is not running');
      return;
    }

    logger.info('🛑 Stopping Risk Manager...');
    this.isRunning = false;
    logger.info('✅ Risk Manager stopped');
  }

  async validateSignal(signal: TradingSignal, analysis: MarketAnalysis): Promise<RiskCheck> {
    try {
      let riskScore = 0;
      const reasons: string[] = [];

      // Check risk score from analysis
      if (analysis.riskScore > 0.8) {
        riskScore += 0.3;
        reasons.push('High risk score from analysis');
      }

      // Check signal confidence
      if (signal.confidence < 0.6) {
        riskScore += 0.2;
        reasons.push('Low signal confidence');
      }

      // Check signal strength
      if (signal.strength === 'WEAK') {
        riskScore += 0.1;
        reasons.push('Weak signal strength');
      }

      // Check daily loss limit
      if (this.dailyPnL < -(this.portfolioValue * this.config.maxDailyLoss)) {
        riskScore += 0.5;
        reasons.push('Daily loss limit reached');
      }

      // Check drawdown limit
      const currentDrawdown = (this.maxPortfolioValue - this.portfolioValue) / this.maxPortfolioValue;
      if (currentDrawdown > this.config.maxDrawdown) {
        riskScore += 0.5;
        reasons.push('Maximum drawdown reached');
      }

      const approved = riskScore < 0.7;
      const reason = reasons.length > 0 ? reasons.join(', ') : undefined;

      logger.info(`🛡️ Risk check: ${approved ? 'APPROVED' : 'REJECTED'} (score: ${riskScore.toFixed(2)})`);

      return {
        approved,
        reason,
        riskScore
      };

    } catch (error) {
      logger.error('❌ Error in risk validation:', error);
      return {
        approved: false,
        reason: 'Risk validation error',
        riskScore: 1.0
      };
    }
  }

  async checkStopLoss(symbol: string): Promise<StopLossCheck> {
    try {
      // Mock implementation - in real system, would check actual position
      const currentPrice = 50000; // Mock price
      const entryPrice = 52000; // Mock entry price
      const stopLossPrice = entryPrice * (1 - this.config.stopLossPercentage);

      if (currentPrice <= stopLossPrice) {
        return {
          triggered: true,
          reason: 'Price hit stop-loss level',
          price: currentPrice
        };
      }

      return { triggered: false };

    } catch (error) {
      logger.error(`❌ Error checking stop-loss for ${symbol}:`, error);
      return { triggered: false };
    }
  }

  async checkTakeProfit(symbol: string): Promise<TakeProfitCheck> {
    try {
      // Mock implementation - in real system, would check actual position
      const currentPrice = 50000; // Mock price
      const entryPrice = 45000; // Mock entry price
      const takeProfitPrice = entryPrice * (1 + this.config.takeProfitPercentage);

      if (currentPrice >= takeProfitPrice) {
        return {
          triggered: true,
          reason: 'Price hit take-profit level',
          price: currentPrice
        };
      }

      return { triggered: false };

    } catch (error) {
      logger.error(`❌ Error checking take-profit for ${symbol}:`, error);
      return { triggered: false };
    }
  }

  async updateTrailingStop(symbol: string): Promise<void> {
    try {
      // Mock implementation - would update trailing stop based on price movement
      logger.debug(`📊 Updated trailing stop for ${symbol}`);
    } catch (error) {
      logger.error(`❌ Error updating trailing stop for ${symbol}:`, error);
    }
  }

  async getRiskAllocation(): Promise<{
    maxPositionSize: number;
    currentAllocation: number;
    availableAllocation: number;
  }> {
    const maxPositionSize = this.portfolioValue * this.config.maxPositionSize;
    const currentAllocation = 0; // Would calculate from actual positions
    const availableAllocation = maxPositionSize - currentAllocation;

    return {
      maxPositionSize,
      currentAllocation,
      availableAllocation
    };
  }

  async getRiskMetrics(): Promise<RiskMetrics> {
    const currentDrawdown = (this.maxPortfolioValue - this.portfolioValue) / this.maxPortfolioValue;
    const volatility = 0.15; // Mock volatility calculation

    return {
      currentDrawdown,
      dailyPnL: this.dailyPnL,
      openPositions: 0, // Would get from position manager
      portfolioValue: this.portfolioValue,
      riskScore: currentDrawdown / this.config.maxDrawdown,
      volatility
    };
  }

  async updatePortfolioValue(value: number): Promise<void> {
    this.portfolioValue = value;
    this.maxPortfolioValue = Math.max(this.maxPortfolioValue, value);
  }

  async updateDailyPnL(pnl: number): Promise<void> {
    this.dailyPnL = pnl;
  }

  async resetDailyPnL(): Promise<void> {
    this.dailyPnL = 0;
  }

  async updateConfig(newConfig: Partial<RiskConfig>): Promise<void> {
    this.config = { ...this.config, ...newConfig };
    logger.info('📊 Risk configuration updated');
  }

  async getConfig(): Promise<RiskConfig> {
    return { ...this.config };
  }
}
