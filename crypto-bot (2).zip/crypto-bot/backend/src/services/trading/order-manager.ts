import { logger } from '../../utils/logger';
import { Order } from '../exchanges/exchange-connector';

export interface OrderRequest {
  symbol: string;
  side: 'BUY' | 'SELL';
  type: 'MARKET' | 'LIMIT';
  amount: number;
  price?: number;
  stopLoss?: number;
  takeProfit?: number;
  trailingStop?: boolean;
}

export interface OrderResult {
  success: boolean;
  orderId?: string;
  error?: string;
  order?: Order;
}

export class OrderManager {
  private isRunning: boolean = false;
  private activeOrders: Map<string, Order> = new Map();
  private orderHistory: Order[] = [];

  async initialize(): Promise<void> {
    logger.info('📋 Initializing Order Manager...');
    logger.info('✅ Order Manager initialized');
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('⚠️ Order Manager is already running');
      return;
    }

    logger.info('🚀 Starting Order Manager...');
    this.isRunning = true;
    logger.info('✅ Order Manager started');
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      logger.warn('⚠️ Order Manager is not running');
      return;
    }

    logger.info('🛑 Stopping Order Manager...');
    this.isRunning = false;
    logger.info('✅ Order Manager stopped');
  }

  async createOrder(request: OrderRequest): Promise<OrderResult> {
    try {
      logger.info(`📊 Creating order: ${request.side} ${request.amount} ${request.symbol}`);

      // Mock order creation
      const order: Order = {
        id: `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        symbol: request.symbol,
        side: request.side,
        type: request.type,
        amount: request.amount,
        price: request.price,
        status: 'PENDING',
        timestamp: new Date()
      };

      // Simulate order processing
      setTimeout(() => {
        order.status = 'FILLED';
        this.activeOrders.delete(order.id);
        this.orderHistory.push(order);
        logger.info(`✅ Order filled: ${order.id}`);
      }, 1000);

      this.activeOrders.set(order.id, order);

      return {
        success: true,
        orderId: order.id,
        order
      };

    } catch (error) {
      logger.error('❌ Failed to create order:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  async cancelOrder(orderId: string): Promise<boolean> {
    try {
      const order = this.activeOrders.get(orderId);
      if (!order) {
        logger.warn(`⚠️ Order not found: ${orderId}`);
        return false;
      }

      order.status = 'CANCELLED';
      this.activeOrders.delete(orderId);
      this.orderHistory.push(order);

      logger.info(`❌ Order cancelled: ${orderId}`);
      return true;

    } catch (error) {
      logger.error(`❌ Failed to cancel order ${orderId}:`, error);
      return false;
    }
  }

  async getOrder(orderId: string): Promise<Order | null> {
    // Check active orders first
    const activeOrder = this.activeOrders.get(orderId);
    if (activeOrder) {
      return activeOrder;
    }

    // Check order history
    return this.orderHistory.find(order => order.id === orderId) || null;
  }

  async getActiveOrders(symbol?: string): Promise<Order[]> {
    const orders = Array.from(this.activeOrders.values());
    
    if (symbol) {
      return orders.filter(order => order.symbol === symbol);
    }
    
    return orders;
  }

  async getOrderHistory(symbol?: string, limit: number = 100): Promise<Order[]> {
    let history = this.orderHistory.slice(-limit);
    
    if (symbol) {
      history = history.filter(order => order.symbol === symbol);
    }
    
    return history;
  }

  async updateOrderStatus(orderId: string, status: Order['status']): Promise<void> {
    const order = this.activeOrders.get(orderId);
    if (order) {
      order.status = status;
      
      if (status === 'FILLED' || status === 'CANCELLED' || status === 'REJECTED') {
        this.activeOrders.delete(orderId);
        this.orderHistory.push(order);
      }
      
      logger.info(`📊 Order status updated: ${orderId} -> ${status}`);
    }
  }

  async getOrderStats(): Promise<{
    total: number;
    pending: number;
    filled: number;
    cancelled: number;
    rejected: number;
  }> {
    const activeOrders = Array.from(this.activeOrders.values());
    const allOrders = [...activeOrders, ...this.orderHistory];

    return {
      total: allOrders.length,
      pending: activeOrders.filter(o => o.status === 'PENDING').length,
      filled: allOrders.filter(o => o.status === 'FILLED').length,
      cancelled: allOrders.filter(o => o.status === 'CANCELLED').length,
      rejected: allOrders.filter(o => o.status === 'REJECTED').length
    };
  }
}
