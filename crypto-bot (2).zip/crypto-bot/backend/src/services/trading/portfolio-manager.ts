import { logger } from '../../utils/logger';
import { TradingSignal, MarketAnalysis } from '../ai-engine';
import { Order } from '../exchanges/exchange-connector';

export interface Portfolio {
  id: string;
  name: string;
  totalValue: number;
  cash: number;
  positions: PortfolioPosition[];
  lastUpdate: Date;
}

export interface PortfolioPosition {
  symbol: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  marketValue: number;
  unrealizedPnL: number;
  percentage: number;
}

export interface PortfolioCheck {
  approved: boolean;
  reason?: string;
  availableCash: number;
  maxPositionSize: number;
}

export interface PortfolioRecommendation {
  action: 'BUY' | 'SELL' | 'HOLD' | 'REBALANCE';
  symbol?: string;
  amount?: number;
  reason: string;
  confidence: number;
}

export class PortfolioManager {
  private isRunning: boolean = false;
  private portfolio: Portfolio;
  private tradeHistory: Order[] = [];

  constructor() {
    this.portfolio = {
      id: 'main',
      name: 'Main Portfolio',
      totalValue: 10000,
      cash: 10000,
      positions: [],
      lastUpdate: new Date()
    };
  }

  async initialize(): Promise<void> {
    logger.info('💼 Initializing Portfolio Manager...');
    logger.info('✅ Portfolio Manager initialized');
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('⚠️ Portfolio Manager is already running');
      return;
    }

    logger.info('🚀 Starting Portfolio Manager...');
    this.isRunning = true;
    logger.info('✅ Portfolio Manager started');
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      logger.warn('⚠️ Portfolio Manager is not running');
      return;
    }

    logger.info('🛑 Stopping Portfolio Manager...');
    this.isRunning = false;
    logger.info('✅ Portfolio Manager stopped');
  }

  async validateSignal(signal: TradingSignal, analysis: MarketAnalysis): Promise<PortfolioCheck> {
    try {
      const maxPositionSize = this.portfolio.totalValue * 0.05; // 5% max position
      const availableCash = this.portfolio.cash;

      // Check if we have enough cash
      if (availableCash < 100) { // Minimum $100
        return {
          approved: false,
          reason: 'Insufficient cash',
          availableCash,
          maxPositionSize
        };
      }

      // Check if we already have a position in this symbol
      const existingPosition = this.portfolio.positions.find(p => p.symbol === analysis.symbol);
      if (existingPosition && signal.type === 'BUY') {
        return {
          approved: false,
          reason: 'Position already exists',
          availableCash,
          maxPositionSize
        };
      }

      // Check if we have a position to sell
      if (!existingPosition && signal.type === 'SELL') {
        return {
          approved: false,
          reason: 'No position to sell',
          availableCash,
          maxPositionSize
        };
      }

      return {
        approved: true,
        availableCash,
        maxPositionSize
      };

    } catch (error) {
      logger.error('❌ Error in portfolio validation:', error);
      return {
        approved: false,
        reason: 'Portfolio validation error',
        availableCash: 0,
        maxPositionSize: 0
      };
    }
  }

  async updatePosition(tradeResult: any): Promise<void> {
    try {
      if (!tradeResult.success || !tradeResult.order) {
        return;
      }

      const order = tradeResult.order;
      const position = this.portfolio.positions.find(p => p.symbol === order.symbol);

      if (order.side === 'BUY') {
        if (position) {
          // Update existing position
          const totalQuantity = position.quantity + order.amount;
          const totalCost = (position.quantity * position.averagePrice) + (order.amount * (order.price || 50000));
          position.quantity = totalQuantity;
          position.averagePrice = totalCost / totalQuantity;
        } else {
          // Create new position
          const newPosition: PortfolioPosition = {
            symbol: order.symbol,
            quantity: order.amount,
            averagePrice: order.price || 50000,
            currentPrice: order.price || 50000,
            marketValue: order.amount * (order.price || 50000),
            unrealizedPnL: 0,
            percentage: 0
          };
          this.portfolio.positions.push(newPosition);
        }

        // Update cash
        this.portfolio.cash -= order.amount * (order.price || 50000);

      } else if (order.side === 'SELL') {
        if (position) {
          // Update position
          position.quantity -= order.amount;
          if (position.quantity <= 0) {
            // Remove position if quantity is 0 or negative
            this.portfolio.positions = this.portfolio.positions.filter(p => p.symbol !== order.symbol);
          }
        }

        // Update cash
        this.portfolio.cash += order.amount * (order.price || 50000);
      }

      // Update portfolio value
      await this.updatePortfolioValue();
      
      // Record trade
      this.tradeHistory.push(order);

      logger.info(`📊 Portfolio updated: ${order.side} ${order.amount} ${order.symbol}`);

    } catch (error) {
      logger.error('❌ Error updating portfolio position:', error);
    }
  }

  async getTotalValue(): Promise<number> {
    await this.updatePortfolioValue();
    return this.portfolio.totalValue;
  }

  async getPortfolio(): Promise<Portfolio> {
    await this.updatePortfolioValue();
    return { ...this.portfolio };
  }

  async getActiveSymbols(): Promise<string[]> {
    return this.portfolio.positions.map(p => p.symbol);
  }

  private async updatePortfolioValue(): Promise<void> {
    try {
      let totalValue = this.portfolio.cash;

      // Update position values
      for (const position of this.portfolio.positions) {
        // Mock current price - in real system would fetch from exchange
        const currentPrice = position.currentPrice * (1 + (Math.random() - 0.5) * 0.02);
        position.currentPrice = currentPrice;
        position.marketValue = position.quantity * currentPrice;
        position.unrealizedPnL = position.marketValue - (position.quantity * position.averagePrice);
        
        totalValue += position.marketValue;
      }

      // Update position percentages
      for (const position of this.portfolio.positions) {
        position.percentage = (position.marketValue / totalValue) * 100;
      }

      this.portfolio.totalValue = totalValue;
      this.portfolio.lastUpdate = new Date();

    } catch (error) {
      logger.error('❌ Error updating portfolio value:', error);
    }
  }

  async getPosition(symbol: string): Promise<PortfolioPosition | null> {
    await this.updatePortfolioValue();
    return this.portfolio.positions.find(p => p.symbol === symbol) || null;
  }

  async getPositions(): Promise<PortfolioPosition[]> {
    await this.updatePortfolioValue();
    return [...this.portfolio.positions];
  }

  async getCash(): Promise<number> {
    return this.portfolio.cash;
  }

  async getTradeHistory(limit: number = 100): Promise<Order[]> {
    return this.tradeHistory.slice(-limit);
  }

  async getPortfolioStats(): Promise<{
    totalValue: number;
    cash: number;
    invested: number;
    positions: number;
    totalPnL: number;
    returnPercentage: number;
  }> {
    await this.updatePortfolioValue();
    
    const invested = this.portfolio.totalValue - this.portfolio.cash;
    const totalPnL = this.portfolio.positions.reduce((sum, pos) => sum + pos.unrealizedPnL, 0);
    const returnPercentage = (totalPnL / invested) * 100;

    return {
      totalValue: this.portfolio.totalValue,
      cash: this.portfolio.cash,
      invested,
      positions: this.portfolio.positions.length,
      totalPnL,
      returnPercentage
    };
  }

  async rebalancePortfolio(targetAllocations: Record<string, number>): Promise<PortfolioRecommendation[]> {
    try {
      await this.updatePortfolioValue();
      const recommendations: PortfolioRecommendation[] = [];

      for (const [symbol, targetPercentage] of Object.entries(targetAllocations)) {
        const currentPosition = this.portfolio.positions.find(p => p.symbol === symbol);
        const currentPercentage = currentPosition ? currentPosition.percentage : 0;
        const targetValue = this.portfolio.totalValue * (targetPercentage / 100);

        if (Math.abs(currentPercentage - targetPercentage) > 2) { // 2% threshold
          if (currentPercentage < targetPercentage) {
            // Need to buy
            const buyAmount = targetValue - (currentPosition?.marketValue || 0);
            if (buyAmount > 100) { // Minimum $100
              recommendations.push({
                action: 'BUY',
                symbol,
                amount: buyAmount,
                reason: `Rebalance to ${targetPercentage.toFixed(1)}%`,
                confidence: 0.8
              });
            }
          } else {
            // Need to sell
            const sellAmount = (currentPosition?.marketValue || 0) - targetValue;
            if (sellAmount > 100) { // Minimum $100
              recommendations.push({
                action: 'SELL',
                symbol,
                amount: sellAmount,
                reason: `Rebalance to ${targetPercentage.toFixed(1)}%`,
                confidence: 0.8
              });
            }
          }
        }
      }

      return recommendations;

    } catch (error) {
      logger.error('❌ Error rebalancing portfolio:', error);
      return [];
    }
  }
}
