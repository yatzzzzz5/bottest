import { logger } from '../../utils/logger';
import { Order } from '../exchanges/exchange-connector';

export interface TradeRecord {
  id: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  amount: number;
  price: number;
  timestamp: Date;
  pnl?: number;
  fees?: number;
}

export interface PerformanceMetrics {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  totalPnL: number;
  averagePnL: number;
  maxDrawdown: number;
  sharpeRatio: number;
  profitFactor: number;
  averageTradeDuration: number;
}

export interface DailyPerformance {
  date: string;
  pnl: number;
  trades: number;
  volume: number;
  drawdown: number;
}

export class PerformanceTracker {
  private isRunning: boolean = false;
  private trades: TradeRecord[] = [];
  private dailyPerformance: Map<string, DailyPerformance> = new Map();
  private startingValue: number = 10000;

  async initialize(): Promise<void> {
    logger.info('📈 Initializing Performance Tracker...');
    logger.info('✅ Performance Tracker initialized');
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('⚠️ Performance Tracker is already running');
      return;
    }

    logger.info('🚀 Starting Performance Tracker...');
    this.isRunning = true;
    logger.info('✅ Performance Tracker started');
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      logger.warn('⚠️ Performance Tracker is not running');
      return;
    }

    logger.info('🛑 Stopping Performance Tracker...');
    this.isRunning = false;
    logger.info('✅ Performance Tracker stopped');
  }

  async recordTrade(tradeResult: any): Promise<void> {
    try {
      if (!tradeResult.success || !tradeResult.order) {
        return;
      }

      const order = tradeResult.order;
      const trade: TradeRecord = {
        id: order.id,
        symbol: order.symbol,
        side: order.side,
        amount: order.amount,
        price: order.price || 50000,
        timestamp: order.timestamp,
        fees: order.amount * (order.price || 50000) * 0.001 // 0.1% fee
      };

      this.trades.push(trade);
      await this.updateDailyPerformance(trade);

      logger.info(`📈 Trade recorded: ${trade.side} ${trade.amount} ${trade.symbol} @ ${trade.price}`);

    } catch (error) {
      logger.error('❌ Error recording trade:', error);
    }
  }

  private async updateDailyPerformance(trade: TradeRecord): Promise<void> {
    try {
      const date = trade.timestamp.toISOString().split('T')[0];
      const existing = this.dailyPerformance.get(date) || {
        date,
        pnl: 0,
        trades: 0,
        volume: 0,
        drawdown: 0
      };

      existing.trades += 1;
      existing.volume += trade.amount * trade.price;

      // Calculate PnL for completed trades (simplified)
      if (trade.side === 'SELL') {
        const buyTrade = this.trades.find(t => 
          t.symbol === trade.symbol && 
          t.side === 'BUY' && 
          t.timestamp < trade.timestamp
        );
        
        if (buyTrade) {
          const pnl = (trade.price - buyTrade.price) * trade.amount - (trade.fees || 0);
          existing.pnl += pnl;
          trade.pnl = pnl;
        }
      }

      this.dailyPerformance.set(date, existing);

    } catch (error) {
      logger.error('❌ Error updating daily performance:', error);
    }
  }

  async getPerformance(): Promise<PerformanceMetrics> {
    try {
      const totalTrades = this.trades.length;
      const winningTrades = this.trades.filter(t => (t.pnl || 0) > 0).length;
      const losingTrades = this.trades.filter(t => (t.pnl || 0) < 0).length;
      const totalPnL = this.trades.reduce((sum, t) => sum + (t.pnl || 0), 0);
      const averagePnL = totalTrades > 0 ? totalPnL / totalTrades : 0;
      const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;

      // Calculate max drawdown
      const maxDrawdown = this.calculateMaxDrawdown();

      // Calculate Sharpe ratio (simplified)
      const returns = this.calculateReturns();
      const sharpeRatio = this.calculateSharpeRatio(returns);

      // Calculate profit factor
      const grossProfit = this.trades
        .filter(t => (t.pnl || 0) > 0)
        .reduce((sum, t) => sum + (t.pnl || 0), 0);
      const grossLoss = Math.abs(this.trades
        .filter(t => (t.pnl || 0) < 0)
        .reduce((sum, t) => sum + (t.pnl || 0), 0));
      const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : 0;

      // Calculate average trade duration
      const averageTradeDuration = this.calculateAverageTradeDuration();

      return {
        totalTrades,
        winningTrades,
        losingTrades,
        winRate,
        totalPnL,
        averagePnL,
        maxDrawdown,
        sharpeRatio,
        profitFactor,
        averageTradeDuration
      };

    } catch (error) {
      logger.error('❌ Error calculating performance metrics:', error);
      return {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        winRate: 0,
        totalPnL: 0,
        averagePnL: 0,
        maxDrawdown: 0,
        sharpeRatio: 0,
        profitFactor: 0,
        averageTradeDuration: 0
      };
    }
  }

  private calculateMaxDrawdown(): number {
    try {
      let peak = this.startingValue;
      let maxDrawdown = 0;
      let currentValue = this.startingValue;

      for (const trade of this.trades) {
        if (trade.pnl) {
          currentValue += trade.pnl;
        }

        if (currentValue > peak) {
          peak = currentValue;
        }

        const drawdown = (peak - currentValue) / peak;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }

      return maxDrawdown * 100; // Return as percentage

    } catch (error) {
      logger.error('❌ Error calculating max drawdown:', error);
      return 0;
    }
  }

  private calculateReturns(): number[] {
    try {
      const returns: number[] = [];
      let currentValue = this.startingValue;

      for (const trade of this.trades) {
        if (trade.pnl) {
          const returnValue = trade.pnl / currentValue;
          returns.push(returnValue);
          currentValue += trade.pnl;
        }
      }

      return returns;

    } catch (error) {
      logger.error('❌ Error calculating returns:', error);
      return [];
    }
  }

  private calculateSharpeRatio(returns: number[]): number {
    try {
      if (returns.length === 0) return 0;

      const mean = returns.reduce((sum, r) => sum + r, 0) / returns.length;
      const variance = returns.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / returns.length;
      const stdDev = Math.sqrt(variance);

      // Assuming risk-free rate of 0 for simplicity
      return stdDev > 0 ? mean / stdDev : 0;

    } catch (error) {
      logger.error('❌ Error calculating Sharpe ratio:', error);
      return 0;
    }
  }

  private calculateAverageTradeDuration(): number {
    try {
      const completedTrades: { buy: TradeRecord; sell: TradeRecord }[] = [];

      // Find completed trades (buy + sell pairs)
      for (const buyTrade of this.trades.filter(t => t.side === 'BUY')) {
        const sellTrade = this.trades.find(t => 
          t.symbol === buyTrade.symbol && 
          t.side === 'SELL' && 
          t.timestamp > buyTrade.timestamp
        );

        if (sellTrade) {
          completedTrades.push({ buy: buyTrade, sell: sellTrade });
        }
      }

      if (completedTrades.length === 0) return 0;

      const totalDuration = completedTrades.reduce((sum, pair) => {
        const duration = pair.sell.timestamp.getTime() - pair.buy.timestamp.getTime();
        return sum + duration;
      }, 0);

      return totalDuration / completedTrades.length; // Return in milliseconds

    } catch (error) {
      logger.error('❌ Error calculating average trade duration:', error);
      return 0;
    }
  }

  async getDailyPerformance(days: number = 30): Promise<DailyPerformance[]> {
    try {
      const sortedDates = Array.from(this.dailyPerformance.keys()).sort();
      const recentDates = sortedDates.slice(-days);

      return recentDates.map(date => this.dailyPerformance.get(date)!);

    } catch (error) {
      logger.error('❌ Error getting daily performance:', error);
      return [];
    }
  }

  async getTradeHistory(limit: number = 100): Promise<TradeRecord[]> {
    return this.trades.slice(-limit);
  }

  async getSymbolPerformance(symbol: string): Promise<{
    totalTrades: number;
    totalPnL: number;
    winRate: number;
    averagePnL: number;
  }> {
    try {
      const symbolTrades = this.trades.filter(t => t.symbol === symbol);
      const totalTrades = symbolTrades.length;
      const totalPnL = symbolTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
      const winningTrades = symbolTrades.filter(t => (t.pnl || 0) > 0).length;
      const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
      const averagePnL = totalTrades > 0 ? totalPnL / totalTrades : 0;

      return {
        totalTrades,
        totalPnL,
        winRate,
        averagePnL
      };

    } catch (error) {
      logger.error(`❌ Error getting performance for ${symbol}:`, error);
      return {
        totalTrades: 0,
        totalPnL: 0,
        winRate: 0,
        averagePnL: 0
      };
    }
  }

  async reset(): Promise<void> {
    try {
      this.trades = [];
      this.dailyPerformance.clear();
      logger.info('📈 Performance tracker reset');
    } catch (error) {
      logger.error('❌ Error resetting performance tracker:', error);
    }
  }
}
