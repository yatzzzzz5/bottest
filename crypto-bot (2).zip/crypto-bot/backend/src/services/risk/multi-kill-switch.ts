export interface KillSwitchConfig {
  maxDailyDrawdownPct: number;
  maxConsecutiveLosses: number;
  maxAvgSlippageBps: number;
  maxLatencyMs: number;
}

export class MultiKillSwitch {
  private cfg: KillSwitchConfig;
  private startEquity: number;
  private consecutiveLosses = 0;
  private slipEwma = 0;
  private latEwma = 0;
  private alpha = 0.2;

  constructor(cfg: KillSwitchConfig, startEquityUsd: number) {
    this.cfg = cfg;
    this.startEquity = startEquityUsd;
  }

  onTrade(pnlUsd: number, slippageBps?: number, latencyMs?: number): void {
    if (pnlUsd <= 0) this.consecutiveLosses++; else this.consecutiveLosses = 0;
    if (slippageBps != null) this.slipEwma = this.slipEwma === 0 ? slippageBps : this.slipEwma * (1 - this.alpha) + slippageBps * this.alpha;
    if (latencyMs != null) this.latEwma = this.latEwma === 0 ? latencyMs : this.latEwma * (1 - this.alpha) + latencyMs * this.alpha;
  }

  shouldStop(currentEquityUsd: number): boolean {
    const ddPct = this.startEquity > 0 ? Math.max(0, (this.startEquity - currentEquityUsd) / this.startEquity) * 100 : 0;
    if (ddPct >= this.cfg.maxDailyDrawdownPct) return true;
    if (this.consecutiveLosses >= this.cfg.maxConsecutiveLosses) return true;
    if (this.slipEwma > this.cfg.maxAvgSlippageBps) return true;
    if (this.latEwma > this.cfg.maxLatencyMs) return true;
    return false;
  }
}


