import { logger } from '../../utils/logger';

export interface CircuitBreakerConfig {
  maxConsecutiveLosses: number;        // Max losses before circuit breaker (e.g., 5)
  maxDailyLosses: number;              // Max daily losses before circuit breaker (e.g., 10)
  maxDrawdownPercentage: number;       // Max drawdown % before circuit breaker (e.g., 0.15 = 15%)
  coolingPeriodMinutes: number;       // Minutes to wait before reset (e.g., 30)
  positionSizeReduction: number;      // Reduce position size by this % (e.g., 0.5 = 50%)
  emergencyStopThreshold: number;     // Emergency stop threshold (e.g., 0.25 = 25%)
}

export interface CircuitBreakerState {
  isActive: boolean;
  triggerReason: string;
  triggerTime: Date;
  consecutiveLosses: number;
  dailyLosses: number;
  currentDrawdown: number;
  positionSizeMultiplier: number;
  coolingPeriodEnd: Date | null;
  emergencyStopActive: boolean;
}

export interface CircuitBreakerCheck {
  shouldStop: boolean;
  shouldReduceSize: boolean;
  reason: string;
  recommendedAction: 'CONTINUE' | 'REDUCE_SIZE' | 'STOP_TRADING' | 'EMERGENCY_STOP';
  positionSizeMultiplier: number;
  warnings: string[];
}

export class CircuitBreakerSystem {
  private config: CircuitBreakerConfig;
  private state: CircuitBreakerState;
  private dailyLossCount: number = 0;
  private consecutiveLossCount: number = 0;
  private lastResetTime: Date = new Date();
  private peakPortfolioValue: number = 100; // Starting value

  constructor(config?: Partial<CircuitBreakerConfig>) {
    this.config = {
      maxConsecutiveLosses: 5,
      maxDailyLosses: 10,
      maxDrawdownPercentage: 0.15,
      coolingPeriodMinutes: 30,
      positionSizeReduction: 0.5,
      emergencyStopThreshold: 0.25,
      ...config
    };

    this.state = {
      isActive: false,
      triggerReason: '',
      triggerTime: new Date(),
      consecutiveLosses: 0,
      dailyLosses: 0,
      currentDrawdown: 0,
      positionSizeMultiplier: 1.0,
      coolingPeriodEnd: null,
      emergencyStopActive: false
    };
  }

  async initialize(): Promise<void> {
    logger.info('🔄 Initializing Circuit Breaker System...');
    this.resetDailyCounters();
    logger.info('✅ Circuit Breaker System initialized');
  }

  async checkCircuitBreaker(
    portfolioValue: number,
    tradeResult?: 'WIN' | 'LOSS'
  ): Promise<CircuitBreakerCheck> {
    try {
      // Update portfolio peak
      if (portfolioValue > this.peakPortfolioValue) {
        this.peakPortfolioValue = portfolioValue;
      }

      // Update counters
      if (tradeResult) {
        this.updateCounters(tradeResult);
      }

      // Calculate current drawdown
      const currentDrawdown = (this.peakPortfolioValue - portfolioValue) / this.peakPortfolioValue;

      // Check if cooling period has ended
      if (this.state.isActive && this.state.coolingPeriodEnd && new Date() > this.state.coolingPeriodEnd) {
        this.resetCircuitBreaker();
        logger.info('🔄 Circuit breaker cooling period ended - resetting');
      }

      // Check emergency stop conditions
      if (currentDrawdown >= this.config.emergencyStopThreshold) {
        return this.triggerEmergencyStop(currentDrawdown);
      }

      // Check circuit breaker conditions
      if (this.consecutiveLossCount >= this.config.maxConsecutiveLosses) {
        return this.triggerCircuitBreaker('CONSECUTIVE_LOSSES', currentDrawdown);
      }

      if (this.dailyLossCount >= this.config.maxDailyLosses) {
        return this.triggerCircuitBreaker('DAILY_LOSSES', currentDrawdown);
      }

      if (currentDrawdown >= this.config.maxDrawdownPercentage) {
        return this.triggerCircuitBreaker('DRAWDOWN', currentDrawdown);
      }

      // Check if we should reduce position size due to recent losses
      if (this.consecutiveLossCount >= 3) {
        return this.reducePositionSize(currentDrawdown);
      }

      // All good - continue trading
      return {
        shouldStop: false,
        shouldReduceSize: false,
        reason: 'All checks passed',
        recommendedAction: 'CONTINUE',
        positionSizeMultiplier: 1.0,
        warnings: []
      };

    } catch (error) {
      logger.error('❌ Error checking circuit breaker:', error);
      return {
        shouldStop: true,
        shouldReduceSize: true,
        reason: 'System error - activating circuit breaker',
        recommendedAction: 'EMERGENCY_STOP',
        positionSizeMultiplier: 0.1,
        warnings: ['🚨 SYSTEM ERROR: Circuit breaker activated due to error']
      };
    }
  }

  private updateCounters(tradeResult: 'WIN' | 'LOSS'): void {
    if (tradeResult === 'LOSS') {
      this.consecutiveLossCount++;
      this.dailyLossCount++;
      logger.warn(`📉 Loss recorded. Consecutive: ${this.consecutiveLossCount}, Daily: ${this.dailyLossCount}`);
    } else if (tradeResult === 'WIN') {
      this.consecutiveLossCount = 0; // Reset consecutive losses on win
      logger.info('✅ Win recorded - resetting consecutive losses');
    }
  }

  private triggerCircuitBreaker(reason: string, currentDrawdown: number): CircuitBreakerCheck {
    this.state = {
      isActive: true,
      triggerReason: reason,
      triggerTime: new Date(),
      consecutiveLosses: this.consecutiveLossCount,
      dailyLosses: this.dailyLossCount,
      currentDrawdown,
      positionSizeMultiplier: this.config.positionSizeReduction,
      coolingPeriodEnd: new Date(Date.now() + this.config.coolingPeriodMinutes * 60 * 1000),
      emergencyStopActive: false
    };

    logger.warn(`🔄 Circuit breaker triggered: ${reason}`);

    return {
      shouldStop: true,
      shouldReduceSize: true,
      reason: `Circuit breaker: ${reason}`,
      recommendedAction: 'STOP_TRADING',
      positionSizeMultiplier: this.config.positionSizeReduction,
      warnings: [
        `🔄 Circuit breaker activated: ${reason}`,
        `⏰ Cooling period: ${this.config.coolingPeriodMinutes} minutes`,
        `📉 Consecutive losses: ${this.consecutiveLossCount}`,
        `📊 Current drawdown: ${(currentDrawdown * 100).toFixed(2)}%`
      ]
    };
  }

  private triggerEmergencyStop(currentDrawdown: number): CircuitBreakerCheck {
    this.state.emergencyStopActive = true;
    this.state.positionSizeMultiplier = 0.1; // Reduce to 10% of original size

    logger.error(`🚨 EMERGENCY STOP triggered! Drawdown: ${(currentDrawdown * 100).toFixed(2)}%`);

    return {
      shouldStop: true,
      shouldReduceSize: true,
      reason: `Emergency stop: ${(currentDrawdown * 100).toFixed(2)}% drawdown`,
      recommendedAction: 'EMERGENCY_STOP',
      positionSizeMultiplier: 0.1,
      warnings: [
        '🚨 EMERGENCY STOP ACTIVATED',
        `📉 Drawdown exceeded ${(this.config.emergencyStopThreshold * 100).toFixed(0)}%`,
        '🛑 All trading suspended until manual intervention',
        '⚠️ Immediate portfolio review required'
      ]
    };
  }

  private reducePositionSize(currentDrawdown: number): CircuitBreakerCheck {
    const reductionFactor = Math.pow(this.config.positionSizeReduction, this.consecutiveLossCount - 2);
    const positionSizeMultiplier = Math.max(0.2, reductionFactor); // Minimum 20% of original size

    logger.warn(`⚠️ Reducing position size due to ${this.consecutiveLossCount} consecutive losses`);

    return {
      shouldStop: false,
      shouldReduceSize: true,
      reason: `${this.consecutiveLossCount} consecutive losses`,
      recommendedAction: 'REDUCE_SIZE',
      positionSizeMultiplier,
      warnings: [
        `⚠️ Position size reduced due to ${this.consecutiveLossCount} consecutive losses`,
        `📊 New position size: ${(positionSizeMultiplier * 100).toFixed(1)}% of original`,
        '🎯 Consider more conservative trading approach'
      ]
    };
  }

  private resetCircuitBreaker(): void {
    this.state = {
      isActive: false,
      triggerReason: '',
      triggerTime: new Date(),
      consecutiveLosses: 0,
      dailyLosses: this.dailyLossCount, // Keep daily count
      currentDrawdown: 0,
      positionSizeMultiplier: 1.0,
      coolingPeriodEnd: null,
      emergencyStopActive: false
    };

    this.consecutiveLossCount = 0;
    logger.info('🔄 Circuit breaker reset - trading can resume');
  }

  // Reset daily counters (call at start of new day)
  resetDailyCounters(): void {
    this.dailyLossCount = 0;
    this.consecutiveLossCount = 0;
    this.lastResetTime = new Date();
    logger.info('🔄 Daily counters reset');
  }

  // Manual reset (for emergency situations)
  manualReset(): void {
    this.resetCircuitBreaker();
    this.resetDailyCounters();
    logger.warn('🔄 Circuit breaker manually reset');
  }

  // Get current state
  getState(): CircuitBreakerState {
    return { ...this.state };
  }

  // Update configuration
  updateConfig(newConfig: Partial<CircuitBreakerConfig>): void {
    this.config = { ...this.config, ...newConfig };
    logger.info('⚙️ Circuit Breaker configuration updated');
  }

  // Check if system is in emergency state
  isEmergencyStopActive(): boolean {
    return this.state.emergencyStopActive;
  }

  // Get current position size multiplier
  getPositionSizeMultiplier(): number {
    return this.state.positionSizeMultiplier;
  }

  // Get time until circuit breaker resets
  getTimeUntilReset(): number | null {
    if (!this.state.coolingPeriodEnd) return null;
    return Math.max(0, this.state.coolingPeriodEnd.getTime() - Date.now());
  }
}
