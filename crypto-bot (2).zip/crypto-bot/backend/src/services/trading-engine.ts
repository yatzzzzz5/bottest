import { logger } from '../utils/logger';
import { ExchangeConnector } from './exchanges/exchange-connector';
import { OrderManager } from './trading/order-manager';
import { PositionManager } from './trading/position-manager';
import { RiskManager } from './trading/risk-manager';
import { StrategyExecutor } from './trading/strategy-executor';
import { PortfolioManager } from './trading/portfolio-manager';
import { PerformanceTracker } from './trading/performance-tracker';
import { TradingSignal, MarketAnalysis, aiEngine } from './ai-engine';
import { DailyTargetManager } from './daily-target-manager';

export class TradingEngine {
  private exchangeConnector: ExchangeConnector;
  private orderManager: OrderManager;
  private positionManager: PositionManager;
  private riskManager: RiskManager;
  private strategyExecutor: StrategyExecutor;
  private portfolioManager: PortfolioManager;
  private performanceTracker: PerformanceTracker;
  private dailyTargetManager: DailyTargetManager;
  
  private isRunning: boolean = false;
  private activeStrategies: Map<string, any> = new Map();
  private lastAISignalAt: Map<string, number> = new Map();
  private lastSuggestedTp: Map<string, number> = new Map();

  constructor() {
    this.exchangeConnector = new ExchangeConnector();
    this.orderManager = new OrderManager();
    this.positionManager = new PositionManager();
    this.riskManager = new RiskManager();
    this.strategyExecutor = new StrategyExecutor();
    this.portfolioManager = new PortfolioManager();
    this.performanceTracker = new PerformanceTracker();
    const tm = Number(process.env.DAILY_TARGET_MULTIPLE || '2');
    const mt = Number(process.env.MAX_TRADES_PER_DAY || '0');
    const maxTrades = isFinite(mt) && mt > 0 ? Math.floor(mt) : null;
    this.dailyTargetManager = new DailyTargetManager(isFinite(tm) && tm > 0 ? tm : 2.0, maxTrades);
  }

  async initialize(): Promise<void> {
    try {
      logger.info('🚀 Initializing Trading Engine...');
      
      // Initialize all trading components
      await Promise.all([
        this.exchangeConnector.initialize(),
        this.orderManager.initialize(),
        this.positionManager.initialize(),
        this.riskManager.initialize(),
        this.strategyExecutor.initialize(),
        this.portfolioManager.initialize(),
        this.performanceTracker.initialize(),
        this.dailyTargetManager.initialize()
      ]);
      
      logger.info('✅ Trading Engine initialized successfully');
    } catch (error) {
      logger.error('❌ Failed to initialize Trading Engine:', error);
      throw error;
    }
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('⚠️ Trading Engine is already running');
      return;
    }

    try {
      logger.info('🚀 Starting Trading Engine...');
      
      this.isRunning = true;
      
      // Start all trading components
      await Promise.all([
        this.exchangeConnector.start(),
        this.orderManager.start(),
        this.positionManager.start(),
        this.riskManager.start(),
        this.strategyExecutor.start(),
        this.portfolioManager.start(),
        this.performanceTracker.start(),
        this.dailyTargetManager.start()
      ]);
      
      logger.info('✅ Trading Engine started successfully');
      
      // Start market monitoring
      this.startMarketMonitoring();
      
    } catch (error) {
      this.isRunning = false;
      logger.error('❌ Failed to start Trading Engine:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      logger.warn('⚠️ Trading Engine is not running');
      return;
    }

    try {
      logger.info('🛑 Stopping Trading Engine...');
      
      this.isRunning = false;
      
      // Stop all trading components
      await Promise.all([
        this.exchangeConnector.stop(),
        this.orderManager.stop(),
        this.positionManager.stop(),
        this.riskManager.stop(),
        this.strategyExecutor.stop(),
        this.portfolioManager.stop(),
        this.performanceTracker.stop(),
        this.dailyTargetManager.stop()
      ]);
      
      logger.info('✅ Trading Engine stopped successfully');
      
    } catch (error) {
      logger.error('❌ Failed to stop Trading Engine:', error);
      throw error;
    }
  }

  async executeSignal(signal: TradingSignal, analysis: MarketAnalysis): Promise<boolean> {
    try {
      logger.info(`📊 Executing signal: ${signal.type} ${signal.strength} for ${analysis.symbol}`);
      
      // Ensure daily state is initialized and check allowance
      const portfolioValueForInit = await this.portfolioManager.getTotalValue();
      await this.dailyTargetManager.ensureDayInitialized(portfolioValueForInit);
      const allow = await this.dailyTargetManager.isTradingAllowed(portfolioValueForInit);
      if (!allow.allowed) {
        logger.warn(`🛑 Trading blocked by DailyTargetManager: ${allow.reason}`);
        return false;
      }

      // Risk check
      const riskCheck = await this.riskManager.validateSignal(signal, analysis);
      if (!riskCheck.approved) {
        logger.warn(`⚠️ Signal rejected by risk manager: ${riskCheck.reason}`);
        return false;
      }
      
      // Portfolio check
      const portfolioCheck = await this.portfolioManager.validateSignal(signal, analysis);
      if (!portfolioCheck.approved) {
        logger.warn(`⚠️ Signal rejected by portfolio manager: ${portfolioCheck.reason}`);
        return false;
      }
      
      // Calculate position size
      const positionSize = await this.calculatePositionSize(signal, analysis);
      
      // Execute trade
      const tradeResult = await this.strategyExecutor.execute({
        symbol: analysis.symbol,
        signal,
        positionSize,
        analysis,
        timestamp: new Date()
      });
      
      if (tradeResult.success) {
        logger.info(`✅ Signal executed successfully: ${tradeResult.orderId}`);
        
        // Update portfolio
        await this.portfolioManager.updatePosition(tradeResult);
        
        // Track performance
        await this.performanceTracker.recordTrade(tradeResult);

        // Update daily target status post-trade
        const currentEquity = await this.portfolioManager.getTotalValue();
        await this.dailyTargetManager.onTrade(tradeResult, currentEquity);

        // Set take-profit: prefer AI suggested TP if it yields >= $1 profit; otherwise fallback to ~$1 TP
        try {
          const portfolio = await this.getPortfolio();
          const pos = portfolio?.positions?.find((p: any) => p.symbol === tradeResult?.order?.symbol);
          const qty = Number(pos?.quantity || tradeResult?.order?.amount || 0);
          const avgPx = Number(pos?.averagePrice || tradeResult?.order?.price || 0);
          if (qty > 0 && avgPx > 0) {
            const isBuy = tradeResult?.order?.side === 'BUY';
            const suggested = this.lastSuggestedTp.get(tradeResult.order.symbol);
            let tp = 0;

            if (typeof suggested === 'number' && isFinite(suggested)) {
              const profitUsd = Math.abs((suggested - avgPx) * qty);
              const directionOk = isBuy ? (suggested > avgPx) : (suggested < avgPx);
              if (directionOk && profitUsd >= 1) {
                tp = suggested; // honor AI suggestion if >= $1 profit
              }
            }

            if (!tp) {
              const delta = 1 / qty; // price change to earn ~$1
              tp = isBuy ? (avgPx + delta) : (avgPx - delta);
            }

            await this.positionManager.updateTakeProfit(tradeResult.order.symbol, tp);
            logger.info(`💰 Set TP for ${tradeResult.order.symbol}: ${tp.toFixed(6)} (qty=${qty}, basePx=${avgPx.toFixed(6)})`);
          }
        } catch (e) {
          logger.warn('⚠️ Failed to set $1 TP:', e);
        }
        
        return true;
      } else {
        logger.error(`❌ Failed to execute signal: ${tradeResult.error}`);
        return false;
      }
      
    } catch (error) {
      logger.error(`❌ Error executing signal:`, error);
      return false;
    }
  }

  private async calculatePositionSize(signal: TradingSignal, analysis: MarketAnalysis): Promise<number> {
    try {
      // Get current portfolio value
      const portfolioValue = await this.portfolioManager.getTotalValue();
      
      // Get risk allocation
      const riskAllocation = await this.riskManager.getRiskAllocation();
      
      // Calculate base position size (1-5% of portfolio)
      const baseSize = portfolioValue * 0.02; // 2% base
      
      // Adjust based on signal strength
      let strengthMultiplier = 1.0;
      switch (signal.strength) {
        case 'WEAK':
          strengthMultiplier = 0.5;
          break;
        case 'MEDIUM':
          strengthMultiplier = 1.0;
          break;
        case 'STRONG':
          strengthMultiplier = 1.5;
          break;
      }
      
      // Adjust based on confidence
      const confidenceMultiplier = signal.confidence;
      
      // Adjust based on risk score
      const riskMultiplier = Math.max(0.1, 1 - analysis.riskScore);
      
      // Calculate final position size
      const positionSize = baseSize * strengthMultiplier * confidenceMultiplier * riskMultiplier;
      
      // Ensure minimum and maximum limits
      const minSize = 10; // $10 minimum
      const maxSize = portfolioValue * 0.1; // 10% maximum
      
      return Math.max(minSize, Math.min(maxSize, positionSize));
      
    } catch (error) {
      logger.error('❌ Error calculating position size:', error);
      return 100; // Default $100 position
    }
  }

  private startMarketMonitoring(): void {
    // Monitor market every 15 seconds
    setInterval(async () => {
      if (!this.isRunning) return;
      
      try {
        // Get active symbols
        const activeSymbols = await this.portfolioManager.getActiveSymbols();
        
        // Monitor each symbol
        for (const symbol of activeSymbols) {
          await this.monitorSymbol(symbol);
        }
        
      } catch (error) {
        logger.error('❌ Error in market monitoring:', error);
      }
    }, 15000);
  }

  private async monitorSymbol(symbol: string): Promise<void> {
    try {
      // Check for stop-loss triggers
      const stopLossCheck = await this.riskManager.checkStopLoss(symbol);
      if (stopLossCheck.triggered) {
        logger.warn(`🛑 Stop-loss triggered for ${symbol}: ${stopLossCheck.reason}`);
        await this.executeStopLoss(symbol, stopLossCheck);
      }
      
      // Check for take-profit triggers
      const takeProfitCheck = await this.riskManager.checkTakeProfit(symbol);
      if (takeProfitCheck.triggered) {
        logger.info(`💰 Take-profit triggered for ${symbol}: ${takeProfitCheck.reason}`);
        await this.executeTakeProfit(symbol, takeProfitCheck);
      }
      
      // Check for trailing stop updates
      await this.riskManager.updateTrailingStop(symbol);

      // AI-driven autonomous signals
      try {
        const now = Date.now();
        const lastAt = this.lastAISignalAt.get(symbol) || 0;
        if (now - lastAt > 15_000) { // 15s minimum interval per symbol
          const analysis = await aiEngine.analyzeMarket(symbol);
          const best = analysis.signals.sort((a, b) => b.confidence - a.confidence)[0];
          if (best && best.confidence >= 0.65 && best.type !== 'HOLD') {
            // Try to also fetch explicit TP suggestion
            try {
              const gen = await aiEngine.generateTradingSignals(symbol);
              if (gen?.takeProfit) this.lastSuggestedTp.set(symbol, Number(gen.takeProfit));
            } catch {}

            const aiSignal: TradingSignal = best;
            const executed = await this.executeSignal(aiSignal, analysis);
            if (executed) this.lastAISignalAt.set(symbol, now);
          }
        }
      } catch (e) {
        logger.warn(`⚠️ AI signal generation failed for ${symbol}:`, e);
      }
      
    } catch (error) {
      logger.error(`❌ Error monitoring symbol ${symbol}:`, error);
    }
  }

  private async executeStopLoss(symbol: string, stopLossCheck: any): Promise<void> {
    try {
      const position = await this.positionManager.getPosition(symbol);
      if (!position) return;
      
      const signal: TradingSignal = {
        type: 'SELL',
        strength: 'STRONG',
        reason: `Stop-loss: ${stopLossCheck.reason}`,
        confidence: 1.0,
        source: 'RISK_MANAGEMENT'
      };
      
      await this.executeSignal(signal, {
        symbol,
        timestamp: new Date(),
        sentiment: { score: 0, confidence: 0, sources: [], timestamp: new Date() },
        technical: { 
          rsi: 0, 
          macd: { macd: 0, signal: 0, histogram: 0 },
          bollingerBands: { upper: 0, middle: 0, lower: 0 },
          sma: { sma20: 0, sma50: 0, sma200: 0 },
          ema: { ema12: 0, ema26: 0 },
          confidence: 0, 
          timestamp: new Date() 
        },
        patterns: [],
        news: { score: 0, confidence: 0, articles: 0, sentiment: 'NEUTRAL', timestamp: new Date() },
        whaleActivity: { score: 0, confidence: 0, largeTransactions: 0, netFlow: 0, timestamp: new Date() },
        prediction: { direction: 'NEUTRAL', confidence: 0, timeframe: '1h', timestamp: new Date() },
        riskScore: 1.0,
        signals: [],
        portfolioRecommendation: { action: 'HOLD', confidence: 0, timestamp: new Date() },
        confidence: 0
      });
      
    } catch (error) {
      logger.error(`❌ Error executing stop-loss for ${symbol}:`, error);
    }
  }

  private async executeTakeProfit(symbol: string, takeProfitCheck: any): Promise<void> {
    try {
      const position = await this.positionManager.getPosition(symbol);
      if (!position) return;
      
      const signal: TradingSignal = {
        type: 'SELL',
        strength: 'STRONG',
        reason: `Take-profit: ${takeProfitCheck.reason}`,
        confidence: 1.0,
        source: 'RISK_MANAGEMENT'
      };
      
      await this.executeSignal(signal, {
        symbol,
        timestamp: new Date(),
        sentiment: { score: 0, confidence: 0, sources: [], timestamp: new Date() },
        technical: { 
          rsi: 0, 
          macd: { macd: 0, signal: 0, histogram: 0 },
          bollingerBands: { upper: 0, middle: 0, lower: 0 },
          sma: { sma20: 0, sma50: 0, sma200: 0 },
          ema: { ema12: 0, ema26: 0 },
          confidence: 0, 
          timestamp: new Date() 
        },
        patterns: [],
        news: { score: 0, confidence: 0, articles: 0, sentiment: 'NEUTRAL', timestamp: new Date() },
        whaleActivity: { score: 0, confidence: 0, largeTransactions: 0, netFlow: 0, timestamp: new Date() },
        prediction: { direction: 'NEUTRAL', confidence: 0, timeframe: '1h', timestamp: new Date() },
        riskScore: 0.0,
        signals: [],
        portfolioRecommendation: { action: 'HOLD', confidence: 0, timestamp: new Date() },
        confidence: 0
      });
      
    } catch (error) {
      logger.error(`❌ Error executing take-profit for ${symbol}:`, error);
    }
  }

  // Public methods for external access
  async getPortfolio(): Promise<any> {
    return await this.portfolioManager.getPortfolio();
  }

  async getPerformance(): Promise<any> {
    return await this.performanceTracker.getPerformance();
  }

  async getActivePositions(): Promise<any[]> {
    return await this.positionManager.getActivePositions();
  }

  async getRiskMetrics(): Promise<any> {
    return await this.riskManager.getRiskMetrics();
  }
}

// Export singleton instance
export const tradingEngine = new TradingEngine();
export async function setupTradingEngine(): Promise<void> {
  await tradingEngine.initialize();
}
